# ai-notebook
AI in HR - ML Notebooks for processing and model 
