import os
import numpy as np
from flask import Flask, request, jsonify, render_template
from werkzeug.utils import secure_filename
import pickle

UPLOAD_FOLDER = '/Users/rajeshhegde/Works/FYP/hr-flask-app/data'
ALLOWED_EXTENSIONS = {'docx', 'pdf'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/', methods=["GET", "POST"])
def hello():
    return jsonify(message="Welcome to AI in HR")


@app.route('/home', methods=["GET", "POST"])
def home():
    return render_template("index.html")


@app.route('/api/upload', methods=["POST"])
def predict():
    # check if the post request has the file part
    if 'file' not in request.files:
        return jsonify(message="Error")
    uploaded_file = request.files['file']
    if uploaded_file.filename == '':
        return jsonify(message="Error")
    if uploaded_file and allowed_file(uploaded_file.filename):
        filename = secure_filename(uploaded_file.filename)
        full_filename = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        uploaded_file.save(full_filename)
        return jsonify(message="Success")
    else:
        return jsonify(message="Error")


# start the flask app, allow remote connections
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
