# hr-flask-app

Flask app for HR Tool

##### Steps while creating new flask app

1. `sudo python get-pip.py`
2. `sudo python -m pip install virtualenv`
3. `python -m venv venv`
4. `. venv/bin/activate` (to start venv)
5. `deactivate` (to stop venv)

##### Running the project

1. `export FLASK_APP=app.py` (App PATH)
2. `export FLASK_ENV=development` (Debug Mode)
3. `flask run`
