import os
# import numpy as np
import datetime
import uuid
from flask import Flask, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from flask_cors import CORS
import re
import json

# ml imports
import fitz
from nltk import word_tokenize
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
from gensim.models import Word2Vec
import numpy
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from pyresparser import ResumeParser
from textblob import TextBlob

# import pickle
ENV = 'prod'

# config
app = Flask(__name__)
CORS(app)

# base directory
basedir = os.path.abspath(os.path.dirname(__file__))

# Upload path
UPLOAD_FOLDER = basedir + '/data'

# file filters
ALLOWED_EXTENSIONS = {'pdf'}

# regex for email
regex = '^(\w|\.|\_|\-)+[@](\w|\_|\-|\.)+[.]\w{2,3}$'

# document upload config
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# database config
if ENV == 'dev':
    app.debug = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:123@localhost/ai_in_hr'
else:
    app.debug = False
    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://nogbcjdhlzmhtl:e229976521864fbb3e7098dfb498404c20189592e813fb55597b70a41c795855@ec2-107-20-153-39.compute-1.amazonaws.com:5432/d1q65lgt2edc1n'

# init db
db = SQLAlchemy(app)
# init ma
ma = Marshmallow(app)

# ML part begins
# Initialize lemmatizer and stopwords
lemmatizer = WordNetLemmatizer()
stopword = set(stopwords.words('english'))

# Load model
w2vmodel = Word2Vec.load("model.pkl")

# Find a word that exists in the model to be used a default
default_word = w2vmodel.wv.most_similar("computer")[0][0]


def getPhraseEmbedding(phrase,embeddingmodel):
    samp = getwordVec(default_word, embeddingmodel)
    vec=numpy.array((0)*len(samp));
    den=0;
    for word in phrase:
        den = den + 1;
        vec = vec+numpy.array(getwordVec(word,embeddingmodel));
    return vec.reshape(1, -1)


def getwordVec(word, model):
    sample = model.wv[default_word]
    vec = [0] * len(sample)
    try:
        vec = model.wv[word]
    except:
        vec = [0] * len(sample)

    return vec


def getSubjectivity(text):
    return TextBlob(text).sentiment.subjectivity


# Create a function to get the polarity
def getPolarity(text):
    return TextBlob(text).sentiment.polarity


def getAnalysis(score):
    if score < 0:
        return 'NEGATIVE'
    else:
        return 'POSITIVE'


# Users Class/Model
class Users(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key = True)
    name = db.Column(db.String(100), nullable = False)
    email = db.Column(db.String(255), nullable = False, unique = True)
    password = db.Column(db.String(255), nullable = False)
    contact_number = db.Column(db.String(20), nullable = False)
    address = db.Column(db.String(255), nullable = False)
    active = db.Column(db.Boolean(), default = True)

    def __init__(self, name, email, password, contact_number, address, active):
        self.name = name
        self.email = email
        self.password = password
        self.contact_number = contact_number
        self.address = address
        self.active = active


# Users Schema
class UsersSchema(ma.Schema):
    class Meta:
        model = Users
        fields = ('id', 'name', 'email', 'contact_number', 'address')


# Init schema
user_schema = UsersSchema()
users_schema = UsersSchema(many = True)


# Resume Class/Model
class Resume(db.Model):
    __tablename__ = "resume"
    id = db.Column(db.Integer, primary_key = True)
    file_name = db.Column(db.String(255), nullable = False)
    processed_data = db.Column(db.Text(), nullable = False)
    created_at = db.Column(db.DateTime(), default = datetime.datetime.utcnow())
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete = "CASCADE"))
    uploaded_user = db.relationship('Users', backref = 'users_resume', lazy = True)

    def __init__(self, file_name, processed_data, created_at, user_id):
        self.file_name = file_name
        self.processed_data = processed_data
        self.created_at = created_at
        self.user_id = user_id


# Resume Schema
class ResumeSchema(ma.Schema):
    uploaded_user = ma.Nested(UsersSchema)

    class Meta:
        model = Resume
        fields = ('id', 'file_name', 'processed_data', 'created_at', 'uploaded_user')


# Init schema
resume_schema = ResumeSchema()
resumes_schema = ResumeSchema(many = True)


# HR Class/Model
class Hr(db.Model):
    __tablename__ = "hr"
    id = db.Column(db.Integer, primary_key = True)
    name = db.Column(db.String(100), nullable = False)
    email = db.Column(db.String(255), nullable = False, unique = True)
    password = db.Column(db.String(255), nullable = False)
    contact_number = db.Column(db.String(20), nullable = False)
    address = db.Column(db.String(255), nullable = False)
    active = db.Column(db.Boolean(), default = True)

    def __init__(self, name, email, password, contact_number, address, active):
        self.name = name
        self.email = email
        self.password = password
        self.contact_number = contact_number
        self.address = address
        self.active = active


# HR Schema
class HrSchema(ma.Schema):
    class Meta:
        model = Hr
        fields = ('id', 'name', 'email', 'contact_number', 'address')


# Init schema
hr_schema = HrSchema()
hrs_schema = HrSchema(many = True)


# Job Description Class/Model
class JobDescription(db.Model):
    __tablename__ = "job_description"
    id = db.Column(db.Integer, primary_key = True)
    title = db.Column(db.String(100), nullable = False)
    description = db.Column(db.Text(), nullable = False)
    role = db.Column(db.String(100), nullable = False)
    link = db.Column(db.String(255), nullable = False)
    experience = db.Column(db.Integer, nullable = False)
    openings = db.Column(db.Integer, nullable = False)
    location = db.Column(db.String(100), nullable = False)
    last_date = db.Column(db.String(50), nullable = False)
    active = db.Column(db.Boolean(), nullable = False, default = True)
    posted_at = db.Column(db.DateTime(), default = datetime.datetime.utcnow)
    posted_by_id = db.Column(db.Integer, db.ForeignKey('hr.id', ondelete = "CASCADE"))
    posted_by = db.relationship('Hr', backref = 'hr', lazy = True)
    job_description_id = db.relationship('Application', backref = 'job_description', lazy = True)
    job_description_results_id = db.relationship('Results', backref = 'job_description', lazy = True)

    def __init__(self, title, description, role, link, location,  experience, openings, last_date, active, posted_at, posted_by_id):
        self.title = title
        self.description = description
        self.role = role,
        self.link = link
        self.active = active
        self.experience = experience
        self.openings = openings
        self.location = location
        self.last_date = last_date
        self.posted_at = posted_at
        self.posted_by_id = posted_by_id


# JD Schema
class JdSchema(ma.Schema):
    posted_by = ma.Nested(HrSchema)

    class Meta:
        model = JobDescription
        fields = ('id', 'title', 'description', 'role', 'link', 'active', 'location','experience', 'openings',
                  'last_date', 'posted_at', 'posted_by')


# Init schema
jd_schema = JdSchema()
jds_schema = JdSchema(many = True)


# Application Class/Model
class Application(db.Model):
    __tablename__ = "application"
    id = db.Column(db.Integer, primary_key = True)
    created_at = db.Column(db.DateTime(), default = datetime.datetime.utcnow)
    jd_id = db.Column(db.Integer, db.ForeignKey('job_description.id', ondelete = "CASCADE"))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete = "CASCADE"))
    user = db.relationship('Users', backref = 'users', lazy = True)
    jd = db.relationship('JobDescription', backref = 'jds', lazy = True, viewonly = True)
    experience = db.Column(db.Integer, nullable = False)
    message = db.Column(db.String(255))

    def __init__(self, created_at, jd_id, user_id, experience, message):
        self.created_at = created_at
        self.jd_id = jd_id
        self.user_id = user_id
        self.experience = experience
        self.message = message


# Application Schema
class ApplicationSchema(ma.Schema):
    user = ma.Nested(UsersSchema)
    jd = ma.Nested(JdSchema)

    class Meta:
        model = Application
        fields = ('id', 'created_at', 'jd', 'user', 'experience', 'message')


# Init schema
application_schema = ApplicationSchema()
applications_schema = ApplicationSchema(many = True)


# Results Class/Model
class Results(db.Model):
    __tablename__ = "results"
    id = db.Column(db.Integer, primary_key = True)
    jd_id = db.Column(db.Integer, db.ForeignKey('job_description.id', ondelete = "CASCADE"))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete = "CASCADE"))
    user = db.relationship('Users', backref = 'applied_user', lazy = True)
    generated_score = db.Column(db.Float, nullable = False)
    feedback = db.Column(db.String(255), nullable = False)
    status = db.Column(db.String(20), nullable = False)
    was_useful = db.Column(db.Boolean(), nullable = False)

    def __init__(self, jd_id, user_id, generated_score, feedback, status, was_useful):
        self.jd_id = jd_id
        self.user_id = user_id
        self.generated_score = generated_score
        self.feedback = feedback
        self.status = status
        self.was_useful = was_useful


# Result Schema
class ResultSchema(ma.Schema):
    user = ma.Nested(UsersSchema)

    class Meta:
        model = Results
        fields = ('id', 'jd_id', 'user', 'generated_score', 'feedback', 'status', 'was_useful')


# Init schema
result_schema = ResultSchema()
results_schema = ResultSchema(many = True)


# allowed files filter method
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# hello route
@app.route('/', methods = ["GET", "POST"])
def hello():
    return jsonify(message = "Welcome to AI in HR")


# signin user
@app.route('/api/signin/user', methods = ["POST"])
def signin_user():
    req = request.get_json()
    email = req.get('email')
    password = req.get('password')

    if len(email) == 0 or len(password) == 0:
        return jsonify(error = "Email or Password can't be empty"), 403

    user = db.session.query(Users).filter(Users.email == email, Users.password == password).first()
    if user:
        result = user_schema.dump(user)
        return jsonify(result), 200
    else:
        return jsonify(error = "Incorrect Email or Password"), 403


# signin hr
@app.route('/api/signin/hr', methods = ["POST"])
def signin_hr():
    req = request.get_json()
    email = req.get('email')
    password = req.get('password')

    if len(email) == 0 or len(password) == 0:
        return jsonify(error = "Email or Password can't be empty"), 403

    hr = db.session.query(Hr).filter(Hr.email == email, Hr.password == password).first()
    if not hr:
        return jsonify(error = "Incorrect Email or Password"), 403
    else:
        result = hr_schema.dump(hr)
        return jsonify(result), 200


# signup user
@app.route('/api/signup/user', methods = ["POST"])
def signup_user():
    req = request.get_json()
    name = req.get('name')
    email = req.get('email')
    password = req.get('password')
    contact_number = req.get('contact_number')
    address = req.get('address')

    if len(name) == 0 or len(email) == 0 or len(password) == 0 or len(contact_number) == 0 or len(address) == 0:
        return jsonify(error = "Please fill all the fields"), 403

    if len(password) < 6:
        return jsonify(error = "Password should me minimum 6 char"), 403

    if not re.search(regex, email):
        return jsonify(error = "Invalid email"), 403

    if db.session.query(Users).filter(Users.email == email).count() == 0:
        data = Users(name = name, email = email, password = password, contact_number = contact_number,
                     address = address, active = True)
        db.session.add(data)
        db.session.commit()
        return user_schema.jsonify(data), 201
    else:
        return jsonify(error = "User Already Exists, Please Signin"), 403


# signup hr
@app.route('/api/signup/hr', methods = ["POST"])
def signup_hr():
    req = request.get_json()
    name = req.get('name')
    email = req.get('email')
    password = req.get('password')
    contact_number = req.get('contact_number')
    address = req.get('address')

    if len(name) == 0 or len(email) == 0 or len(password) == 0 or len(contact_number) == 0 or len(address) == 0:
        return jsonify(error = "Please fill all the fields"), 403

    if len(password) < 6:
        return jsonify(error = "Password should me minimum 6 char"), 403

    if not re.search(regex, email):
        return jsonify(error = "Invalid email"), 403

    if db.session.query(Hr).filter(Hr.email == email).count() == 0:
        data = Hr(name = name, email = email, password = password, contact_number = contact_number,
                  address = address, active = True)
        db.session.add(data)
        db.session.commit()
        return hr_schema.jsonify(data), 201
    else:
        return jsonify(error = "HR Already Exists, Please Signin."), 403


# get all jd - performed by both user and hr
@app.route('/api/job-description/all', methods = ["GET"])
def get_all_jd():
    all_jd = JobDescription.query.order_by(JobDescription.id.desc()).all()
    result = jds_schema.dump(all_jd)
    return jsonify(result), 200


# get jd by id
@app.route('/api/job-description/<jd_id>', methods = ["GET"])
def get_one_jd(jd_id):
    jd = db.session.query(JobDescription).filter(JobDescription.id == jd_id).first()
    if jd:
        result = jd_schema.dump(jd)
        return jsonify(result), 200
    else:
        return jsonify(error = f"Job Description with uid:{jd_id} Not Found"), 404


# get jd by hr_id
@app.route('/api/hr/job-description', methods = ["GET"])
def get_jd_for_hr():
    hr_id = request.args.get('hr_id')
    jd = db.session.query(JobDescription).filter(JobDescription.posted_by_id == hr_id).order_by(
        JobDescription.id.desc())
    if jd:
        result = jds_schema.dump(jd)
        return jsonify(result), 200
    else:
        return jsonify(error = f"Job Description with uid:{jd_id} Not Found"), 404


# add jd - performed by hr
@app.route('/api/hr/job-description', methods = ["POST"])
def add_jd():
    req = request.get_json()
    title = req.get('title')
    description = req.get('description')
    role = req.get('role')
    experience = req.get('experience')
    openings = req.get('openings')
    last_date = req.get('last_date')
    location = req.get('location')
    link = req.get('link')
    posted_by_id = request.args.get('hr_id')
    data = JobDescription(title = title, description = description, role = role, link = link, active = True,
                          last_date = last_date, experience = experience, openings = openings, location = location,
                          posted_by_id = posted_by_id, posted_at = datetime.datetime.utcnow())
    db.session.add(data)
    db.session.commit()
    return jsonify(message = f"Job Added Successfully - uid:{data.id}"), 201


# update jd with jd_id
@app.route('/api/hr/update/job-description/<jd_id>', methods = ["PUT"])
def edit_jd(jd_id):
    hr_id = request.args.get('hr_id')
    jd = db.session.query(JobDescription).filter(JobDescription.id == jd_id,
                                                 JobDescription.posted_by_id == hr_id).first()
    if jd:
        req = request.get_json()
        jd.title = req.get('title')
        jd.description = req.get('description')
        jd.role = req.get('role')
        jd.link = req.get('link')
        jd.experience = req.get('experience')
        jd.openings = req.get('openings')
        jd.location = req.get('location')
        jd.last_date = req.get('last_date')
        jd.active = req.get('active')
        db.session.commit()
        return jsonify(message = f"Job Updated Successfully - uid:{jd.id}"), 202
    else:
        return jsonify(message = f"Not found or You can't update Job Description with uid:{jd_id}"), 403


# delete jd with jd_id
@app.route('/api/hr/delete/job-description/<jd_id>', methods = ["DELETE"])
def delete_jd(jd_id):
    hr_id = request.args.get('hr_id')
    jd = db.session.query(JobDescription).filter(JobDescription.id == jd_id,
                                                 JobDescription.posted_by_id == hr_id).first()
    if jd:
        db.session.delete(jd)
        db.session.commit()
        return jsonify(message = f"Job Deleted Successfully - uid:{jd.id}"), 202
    else:
        return jsonify(message = f"Not found or You can't delete Job Description with uid:{jd_id}"), 403


# get all applications - performed by hr
@app.route('/api/application/all', methods = ["GET"])
def get_all_apps():
    all_apps = Application.query.order_by(Application.id.desc()).all()
    result = applications_schema.dump(all_apps)
    return jsonify(result), 200


# Get all application with user_id - performed by User
@app.route('/api/user/application', methods = ["GET"])
def get_application_for_user():
    user_id = request.args.get('user_id')
    applications = db.session.query(Application).filter(Application.user_id == user_id)
    result = applications_schema.dump(applications)
    return jsonify(result), 200


# Get all application with jd_id - performed by HR
@app.route('/api/application', methods = ["GET"])
def get_application_for_jd_id():
    jd_id = request.args.get('jd_id')
    applications = db.session.query(Application).filter(Application.jd_id == jd_id)
    result = applications_schema.dump(applications)
    return jsonify(result), 200


# apply for job
@app.route('/api/user/apply', methods = ["POST"])
def apply_job():
    req = request.get_json()
    user_id = request.args.get('user_id')
    jd_id = request.args.get('jd_id')
    experience = req.get('experience')
    message = req.get('message')
    application = db.session.query(Application).filter(Application.user_id == user_id,
                                                       Application.jd_id == jd_id).first()
    if not application:
        data = Application(created_at = datetime.datetime.utcnow(), user_id = user_id, jd_id = jd_id,
                           experience = experience, message = message)
        db.session.add(data)
        db.session.commit()
        # calculate score for jd
        # resume data
        user_resume_data = db.session.query(Resume).filter(Resume.user_id == user_id).first()
        sent_r = user_resume_data.processed_data.split('\n')
        full_list_resume = []
        for s in sent_r:
            for word in word_tokenize(s):
                if word.isalpha() and word not in stopword:
                    full_list_resume.append(lemmatizer.lemmatize(word))
        wv_resume = getPhraseEmbedding(full_list_resume, w2vmodel)

        # jd data
        jd_data = db.session.query(JobDescription).filter(JobDescription.id == jd_id).first()
        final_data = str(jd_data.description) + str(jd_data.title) + str(jd_data.role)
        sent_j = final_data.split(' ')

        full_list_jd = []
        for s in sent_j:
            for word in word_tokenize(s):
                if word.isalpha() and word not in stopword:
                    full_list_jd.append(lemmatizer.lemmatize(word))

        # compare
        wv_jd = getPhraseEmbedding(full_list_jd, w2vmodel)
        similarity = cosine_similarity(wv_resume, wv_jd)[0][0] * 100

        # store in results
        result = Results(user_id = user_id, jd_id = jd_id, generated_score = similarity,
                         feedback = '---', status = '---', was_useful=False)
        db.session.add(result)
        db.session.commit()

        return jsonify(message = f"Applied for Job - Score:{similarity}"), 201
    else:
        return jsonify(error = "You have already applied for this Job"), 403


# Get results,
@app.route('/api/hr/results', methods = ["GET"])
def get_results_for_jd():
    jd_id = request.args.get('jd_id')
    result = db.session.query(Results).filter(Results.jd_id == jd_id).order_by(Results.generated_score.desc()).all()
    data = results_schema.dump(result)
    return jsonify(data), 200


# get feedback
@app.route('/api/hr/get-result', methods = ["GET"])
def get_one_feedback():
    user_id = request.args.get('user_id')
    jd_id = request.args.get('jd_id')
    data = db.session.query(Results).filter(Results.user_id == user_id, Results.jd_id == jd_id).first()
    if data:
        result = result_schema.dump(data)
        return jsonify(result), 200
    else:
        return jsonify(message = f"Not found"), 403


# Update feedback
@app.route('/api/hr/update/result', methods = ["PUT"])
def edit_feedback():
    user_id = request.args.get('user_id')
    jd_id = request.args.get('jd_id')
    result = db.session.query(Results).filter(Results.user_id == user_id, Results.jd_id == jd_id).first()
    if result:
        req = request.get_json()
        feedback = req.get('feedback')
        was_useful = req.get('was_useful')
        feedback_status = getAnalysis(getPolarity(feedback))
        result.feedback = feedback
        result.status = feedback_status
        result.was_useful = was_useful
        db.session.commit()
        return jsonify(message = f"Feedback Updated Successfully - uid:{result.id}"), 202
    else:
        return jsonify(message = f"Not found"), 403


# get resume - by user_id
@app.route('/api/user/resume', methods = ["GET"])
def get_user_resume():
    user_id = request.args.get('user_id')
    resume = db.session.query(Resume).filter(Resume.user_id == user_id)
    result = resumes_schema.dump(resume)
    return jsonify(result), 200


# get resume - by resume_id
@app.route('/api/resume', methods = ["GET"])
def get_resume_details():
    resume_id = request.args.get('resume_id')
    resume = db.session.query(Resume).filter(Resume.id == resume_id).first()
    result = resume_schema.dump(resume)
    return jsonify(result), 200


# upload resume
@app.route('/api/resume/upload', methods = ["POST"])
def upload_file():
    user_id = request.form.get('user_id')
    resume = db.session.query(Resume).filter(Resume.user_id == user_id).first()
    if not resume:
        # check if the post request has the file part
        if 'file' not in request.files:
            return jsonify(message = "Error"), 403
        uploaded_file = request.files['file']
        if uploaded_file.filename == '':
            return jsonify(message = "Error"), 403
        if uploaded_file and allowed_file(uploaded_file.filename):
            filename = str(uuid.uuid4()) + "-" + secure_filename(uploaded_file.filename)
            full_filename = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            uploaded_file.save(full_filename)
            with fitz.open(full_filename) as doc:
                resume = ""
                for page in doc:
                    resume += page.getText()
            resume_data = resume.lower()
            data = Resume(user_id = user_id, file_name = str(filename), processed_data = str(resume_data),
                          created_at = datetime.datetime.utcnow())
            db.session.add(data)
            db.session.commit()

            return jsonify(message = "Upload Success"), 200
        else:
            return jsonify(message = "Something went wrong. Try again."), 403
    else:
        return jsonify(message = "You have already uploaded resume"), 403


@app.route('/api/resume/download', methods = ["GET"])
def download_resume():
    file_name = request.args.get('file_name')
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename=file_name)


# delete jd with jd_id
@app.route('/api/delete/resume/<resume_id>', methods = ["DELETE"])
def delete_resume(resume_id):
    user_id = request.args.get('user_id')
    resume = db.session.query(Resume).filter(Resume.id == resume_id, Resume.user_id == user_id).first()
    if resume:
        db.session.delete(resume)
        db.session.commit()
        return jsonify(message = f"Deleted Successfully"), 200
    else:
        return jsonify(message = f"Resume Not found"), 403


# dashboard API - count of users
@app.route('/api/count/user', methods = ["GET"])
def get_user_count():
    count = db.session.query(Users.id).count()
    return jsonify(count = count), 200


# dashboard API - count of HRs
@app.route('/api/count/hr', methods = ["GET"])
def get_hr_count():
    count = db.session.query(Hr.id).count()
    return jsonify(count = count), 200


# dashboard API - count of JDs and Applications
@app.route('/api/count/jd', methods = ["GET"])
def get_jd_app_count():
    result = db.engine.execute("select jd_id, count(user_id) from application group by jd_id")
    return jsonify([dict(r) for r in result]), 200


# start the flask app - allow remote connections
if __name__ == "__main__":
    app.run()
