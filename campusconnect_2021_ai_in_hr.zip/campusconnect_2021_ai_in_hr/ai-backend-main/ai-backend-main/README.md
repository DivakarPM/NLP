# AI in HR

### Docker Postgres Setup
```shell
# pull docker image
docker pull postgres

# Run the container using command :
docker run --name postgresContainer -e POSTGRES_PASSWORD=123 -d -p 5432:5432 postgres

# verify
docker ps

# execute psql commands using command
docker exec -it postgresContainer psql -U postgres

# create database
create DATABASE ai_in_hr;
```

### Running Flask app
```shell
# move to directory
cd flask-app-ai

# starting virtual env
pipenv shell

# Install dependencies
pipenv install

# for installation
pipenv install [package_name]

# running server
flask run

# stop server
CTRL + C

# deactivate virtual env
deactivate
```


### DB Creation
```
# open python cli
python
```
```python
from app import db
db.create_all()
exit()
```

### Issues
```python
# nltk:  Resource punkt not found.
# Solution
# https://stackoverflow.com/questions/26570944/resource-utokenizers-punkt-english-pickle-not-found/26578793#26578793

# SSL error: Open a terminal and take a look at:
# /Applications/Python 3.6/Install Certificates.command

import nltk
nltk.download('punkt')
nltk.download('wordnet')
```
### Deploy
```python
# push code to deployment (heroku)
git push heroku master
```