import { Button } from "@material-ui/core";
import {
  Box,
  CircularProgress,
  Container,
  Grid,
  Typography,
  withStyles,
  Card,
  CardContent,
  LinearProgress,
} from "@material-ui/core";
import {
  AttachFile,
  Close,
  CloudDownload,
  Delete,
  FileCopy,
} from "@material-ui/icons";
import { DropzoneArea } from "material-ui-dropzone";
import React, { Component } from "react";
import {
  deleteResume,
  downloadResume,
  getUserResume,
  uploadResume,
} from "../../../utils/endPoints";
import { store } from "../../../redux/store";
import * as dayjs from "dayjs";
import axios from "axios";
import { IconButton } from "@material-ui/core";
import { CardHeader } from "@material-ui/core";
import { Dialog } from "@material-ui/core";
import { DialogTitle } from "@material-ui/core";
import { DialogContent } from "@material-ui/core";
import { DialogContentText } from "@material-ui/core";
import { DialogActions } from "@material-ui/core";
import { Snackbar } from "@material-ui/core";
import { Alert } from "@material-ui/lab";
import EmptyResume from "../../../assets/resume.svg";
import { Tooltip } from "@material-ui/core";

const useStyles = (theme) => ({
  mainContainer: {
    padding: theme.spacing(0, 12, 0),
  },
  textBlue: {
    color: "#3495DB",
  },
  imageCenter: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  bodyImage: {
    padding: theme.spacing(0, 0, 5),
    height: "auto",
    width: "40%",
    [theme.breakpoints.down("sm")]: {
      height: "auto",
      width: "80%",
    },
  },
  dropzone: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2),
  },
  formContainer: {
    padding: theme.spacing(0, 6, 3),
    [theme.breakpoints.down("sm")]: {
      padding: theme.spacing(0, 2, 3),
    },
  },
  closeButton: {
    position: "absolute",
    right: theme.spacing(1),
    top: theme.spacing(1),
  },
});
class ManageResume extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      id: null,
      file_name: "",
      created_at: "",
      deleteDialogOpen: false,
      deleteSuccess: false,
      addResumeOpen: false,
      files: [],
      error: false,
      errorMessage: "",
      uploadSuccess: false,
      uploading: false,
    };
  }

  componentDidMount() {
    this.getMyResume();
  }

  handleFile = (file) => {
    this.setState({
      files: file,
      error: false,
      errorMessage: "",
    });
  };

  handleDeleteOpen = () => {
    this.setState({ deleteDialogOpen: true });
  };

  handleDeleteClose = () => {
    this.setState({ deleteDialogOpen: false });
  };

  addResumeHandleOpen = () => {
    this.setState({ addResumeOpen: true });
  };

  addResumeHandleClose = () => {
    this.setState({ addResumeOpen: false });
  };

  getMyResume = () => {
    this.setState({ isLoading: true });

    axios
      .get(getUserResume, {
        params: { user_id: store.getState().auth.userData.id },
      })
      .then((response) => {
        if (response.data.length > 0) {
          this.setState({
            file_name: response.data[0].file_name,
            created_at: response.data[0].created_at,
            id: response.data[0].id,
            isLoading: false,
          });
        } else {
          this.setState({
            isLoading: false,
          });
        }
      })
      .catch((err) => {
        console.warn(err);
      });
  };

  onDeleteHandler = () => {
    axios
      .delete(deleteResume + this.state.id, {
        params: { user_id: store.getState().auth.userData.id.toString() },
      })
      .then(() => {
        this.handleDeleteClose();
        this.setState({
          deleteSuccess: true,
          file_name: "",
          created_at: "",
          id: null,
        });

        setTimeout(() => this.setState({ deleteSuccess: false }), 4000);
      })
      .catch((err) => {
        console.warn(err);
      });
  };

  onSubmitHandler = (e) => {
    e.preventDefault();
    this.setState({ uploading: true, error: false });

    const formData = new FormData();
    formData.append("file", this.state.files[0]);
    formData.append("user_id", store.getState().auth.userData.id);
    const config = { headers: { "content-type": "multipart/form-data" } };

    axios
      .post(uploadResume, formData, config)
      .then(() => {
        this.setState({
          files: [],
          uploading: false,
          uploadSuccess: true,
        });
        setTimeout(() => this.setState({ uploadSuccess: false }), 4000);
        this.getMyResume();
        this.addResumeHandleClose();
      })
      .catch((err) => {
        console.warn(err);
        this.setState({
          error: true,
          isLoading: false,
          errorMessage: "Something went wrong, try again",
        });
      });
  };

  handleDownload = () => {
    axios({
      url: downloadResume,
      method: "GET",
      responseType: "blob",
      params: { file_name: this.state.file_name },
    })
      .then((response) => {
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", this.state.file_name);
        document.body.appendChild(link);
        link.click();
      })
      .catch((err) => {
        console.warn(err);
      });
  };
  render() {
    const { classes } = this.props;
    const { created_at, id, error, uploading, errorMessage } = this.state;
    return (
      <Container className={classes.mainContainer}>
        <Snackbar
          open={this.state.deleteSuccess}
          anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
          autoHideDuration={5000}
          onClose={() => {}}
        >
          <Alert variant="filled" severity="error">
            Resume Deleted Successfully
          </Alert>
        </Snackbar>
        <Snackbar
          open={this.state.uploadSuccess}
          anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
          autoHideDuration={5000}
          onClose={() => {}}
        >
          <Alert variant="filled" severity="success">
            Resume Uploaded Successfully
          </Alert>
        </Snackbar>
        <Grid>
          <Box>
            <Typography
              className={classes.textBlue}
              variant="h4"
              color="textPrimary"
              gutterBottom
            >
              {`My Resume`}
            </Typography>
          </Box>
          {!this.state.isLoading && this.state.id == null && (
            <Box mb={2} className={classes.root}>
              <Button
                variant="contained"
                color="secondary"
                startIcon={<FileCopy />}
                fullWidth
                onClick={this.addResumeHandleOpen}
              >
                Add resume
              </Button>
            </Box>
          )}

          {!this.state.isLoading && this.state.id == null && (
            <Box mt={18}>
              <Grid className={classes.imageCenter}>
                <img
                  src={EmptyResume}
                  alt="no-resume"
                  className={classes.bodyImage}
                />
              </Grid>
              <Typography align="center" variant="body2" color="textSecondary">
                Resume not found, please click on Add Resume.
              </Typography>
            </Box>
          )}

          <Box m={2} align="center">
            {this.state.isLoading && <CircularProgress color="primary" />}
          </Box>

          {!this.state.isLoading && this.state.id != null && (
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Card>
                  <CardHeader
                    action={
                      <Box>
                        <Tooltip title="Download Resume">
                          <IconButton
                            aria-label="delete"
                            onClick={() => {
                              this.handleDownload();
                            }}
                          >
                            <CloudDownload />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Delete">
                          <IconButton
                            aria-label="delete"
                            onClick={() => {
                              this.handleDeleteOpen();
                            }}
                          >
                            <Delete />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    }
                    title={`Resume ID: #${id}`}
                  />
                  <CardContent>
                    <Box mt={-3}>
                      <Typography variant="subtitle1" color="textSecondary">
                        Uploaded on:{" "}
                        {dayjs(created_at + "Z").format("ddd, MM : h:mm a")}
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          )}
        </Grid>
        <Dialog
          open={this.state.addResumeOpen}
          onClose={this.addResumeHandleClose}
        >
          <DialogTitle>
            <IconButton
              aria-label="close"
              className={classes.closeButton}
              onClick={this.addResumeHandleClose}
            >
              <Close />
            </IconButton>
          </DialogTitle>
          <DialogContent>
            <Typography
              variant="subtitle1"
              color="primary"
              align="center"
              gutterBottom
            >
              {`Please Upload PDF Document`}
            </Typography>
            <form onSubmit={this.onSubmitHandler}>
              <Grid container spacing={2} className={classes.formContainer}>
                {this.state.error && (
                  <Grid item xs={12}>
                    <Alert severity="error">{`${errorMessage}`}</Alert>
                  </Grid>
                )}
                <Grid container spacing={2}>
                  <Grid item xs={12} className={classes.dropzone}>
                    <DropzoneArea
                      Icon={AttachFile}
                      filesLimit={1}
                      acceptedFiles={["application/pdf"]}
                      onChange={this.handleFile.bind(this)}
                      showAlerts={false}
                      showFileNames
                      dropzoneText={
                        <Typography variant="body1">
                          "Click to add or drag and drop a pdf file"
                        </Typography>
                      }
                    />
                  </Grid>

                  {uploading && (
                    <Grid item xs={12}>
                      <LinearProgress />
                    </Grid>
                  )}
                  <Grid item xs={12}>
                    <Button
                      fullWidth
                      type="submit"
                      variant="contained"
                      color="primary"
                      disabled={error || uploading}
                    >
                      {`Upload`}
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
            </form>
          </DialogContent>
        </Dialog>
        <Dialog
          open={this.state.deleteDialogOpen}
          onClose={this.handleDeleteClose}
          fullWidth
        >
          <DialogTitle>{"Hold on!"}</DialogTitle>
          <DialogContent>
            <DialogContentText>
              Are you sure you want to Delete ?
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleDeleteClose} color="secondary">
              Cancel
            </Button>
            <Button onClick={this.onDeleteHandler} color="secondary" autoFocus>
              Confirm
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
    );
  }
}

export default withStyles(useStyles)(ManageResume);
