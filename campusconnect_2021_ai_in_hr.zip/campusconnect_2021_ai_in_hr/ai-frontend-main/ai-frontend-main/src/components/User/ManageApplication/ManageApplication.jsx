import { Button } from "@material-ui/core";
import { Card } from "@material-ui/core";
import { CardActions } from "@material-ui/core";
import { CardContent } from "@material-ui/core";
import {
  Box,
  CircularProgress,
  Container,
  Grid,
  Typography,
  withStyles,
} from "@material-ui/core";
import axios from "axios";
import React, { Component } from "react";
import { getAppById } from "../../../utils/endPoints";
import { store } from "../../../redux/store";
import * as dayjs from "dayjs";
import { Search } from "@material-ui/icons";
import { Link } from "react-router-dom";
import ApplyJob from "../../../assets/job-offers.svg";

const useStyles = (theme) => ({
  mainContainer: {
    padding: theme.spacing(0, 12, 0),
  },
  textBlue: {
    color: "#3495DB",
  },
  imageCenter: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  bodyImage: {
    padding: theme.spacing(0, 0, 5),
    height: "auto",
    width: "40%",
    [theme.breakpoints.down("sm")]: {
      height: "auto",
      width: "80%",
    },
  },
});
class ManageApplication extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      applications: [],
    };
  }
  componentDidMount() {
    this.getAllApps();
  }

  getAllApps = () => {
    this.setState({ isLoading: true });

    axios
      .get(getAppById, {
        params: { user_id: store.getState().auth.userData.id },
      })
      .then((response) => {
        this.setState({ applications: response.data, isLoading: false });
      })
      .catch((err) => {
        console.warn(err);
      });
  };
  render() {
    const { classes } = this.props;
    return (
      <Container className={classes.mainContainer}>
        <Box>
          <Typography
            className={classes.textBlue}
            variant="h4"
            color="textPrimary"
            gutterBottom
          >
            {`My Applications`}
          </Typography>
        </Box>
        <Box mb={2} className={classes.root}>
          <Link to="/jobs">
            <Button
              startIcon={<Search />}
              variant="contained"
              color="secondary"
              fullWidth
            >
              Explore all Jobs
            </Button>
          </Link>
        </Box>
        {!this.state.isLoading && this.state.applications.length === 0 && (
          <Box mt={18}>
            <Grid className={classes.imageCenter}>
              <img
                src={ApplyJob}
                alt="apply-for-job"
                className={classes.bodyImage}
              />
            </Grid>
            <Typography align="center" variant="body2" color="textSecondary">
              You have not applied to any jobs.
            </Typography>
          </Box>
        )}
        <Box m={2} align="center">
          {this.state.isLoading && <CircularProgress color="primary" />}
        </Box>
        <Box>
          {!this.state.isLoading && (
            <Grid container spacing={3}>
              {this.state.applications.map((app) => (
                <Grid item xs={12}>
                  <Card>
                    <CardContent>
                      <Typography gutterBottom variant="h5" component="h2">
                        {app.jd.role}
                      </Typography>
                      <Typography
                        gutterBottom
                        variant="subtitle1"
                        component="h2"
                      >
                        Message: {app.message}
                      </Typography>
                      <Typography
                        variant="caption"
                        color="textSecondary"
                        component="p"
                      >
                        Applied on:{" "}
                        {dayjs(app.created_at + "Z").format("ddd, MM : h:mm a")}
                      </Typography>
                    </CardContent>
                    <CardActions>
                      <Link
                        to={`/job-description/${app.jd.id}`}
                        target="_blank"
                      >
                        <Button size="small" color="secondary">
                          Go to Job Descriptoin
                        </Button>
                      </Link>
                    </CardActions>
                  </Card>
                </Grid>
              ))}
            </Grid>
          )}
        </Box>
      </Container>
    );
  }
}

export default withStyles(useStyles)(ManageApplication);
