import React, { Component } from "react";
import { Box, CircularProgress, Paper, withStyles } from "@material-ui/core";
import {
  Grid,
  Table,
  TableHeaderRow,
  PagingPanel,
  Toolbar,
  SearchPanel,
  ExportPanel,
  TableEditColumn,
} from "@devexpress/dx-react-grid-material-ui";
import {
  SearchState,
  IntegratedFiltering,
  PagingState,
  IntegratedPaging,
  SortingState,
  IntegratedSorting,
  EditingState,
} from "@devexpress/dx-react-grid";
import FileSaver from "file-saver";
import { getAllResults } from "../../../utils/endPoints";
import axios from "axios";

const getBgScoreColor = (value) => {
  if (value > 70) {
    return "#EDF7ED";
  } else if (value > 40) {
    return "#FEF4E5";
  } else {
    return "#FCECEA";
  }
};

const getScoreColor = (value) => {
  if (value > 70) {
    return "#357a38";
  } else if (value > 40) {
    return "#ff9800";
  } else {
    return "#f44336";
  }
};

const getBgFeedbackColor = (value) => {
  if (value === "POSITIVE") {
    return "#EDF7ED";
  } else if (value === "---") {
    return "#E8F4FD";
  } else {
    return "#FCECEA";
  }
};

const getFeedbackColor = (value) => {
  if (value === "POSITIVE") {
    return "#357a38";
  } else if (value === "---") {
    return "#3197F3";
  } else {
    return "#f44336";
  }
};

const HighlightedCell = ({ value, style, ...restProps }) => (
  <Table.Cell
    {...restProps}
    style={{
      ...style,
    }}
  >
    <span
      style={{
        backgroundColor: getBgScoreColor(value),
        color: getScoreColor(value),
        fontWeight: 800,
        padding: "6px",
        borderRadius: "5px",
      }}
    >
      {value}
    </span>
  </Table.Cell>
);

const HighlightedFeedbackCell = ({ value, style, ...restProps }) => (
  <Table.Cell
    {...restProps}
    style={{
      ...style,
    }}
  >
    <span
      style={{
        backgroundColor: getBgFeedbackColor(value),
        color: getFeedbackColor(value),
        fontWeight: 800,
        padding: "6px",
        borderRadius: "5px",
      }}
    >
      {value}
    </span>
  </Table.Cell>
);

const Cell = (props) => {
  const { column } = props;
  if (column.name === "generatedScore") {
    return <HighlightedCell {...props} />;
  }
  if (column.name === "status") {
    return <HighlightedFeedbackCell {...props} />;
  }
  return <Table.Cell {...props} />;
};

const useStyles = (theme) => ({
  root: {
    marginTop: theme.spacing(3),
  },
  button: {
    color: "blue",
  },
});

class JdTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      feedBackFromShow: false,
      feedBack: "",
      searchText: "",
      rows: [],
      columns: [
        { name: "rank", title: "Rank" },
        { name: "userName", title: "Name" },
        { name: "email", title: "Email" },
        { name: "contactNumber", title: "Mobile" },
        { name: "status", title: "Feedback" },
        { name: "generatedScore", title: "Score %" },
      ],
    };
  }

  editButton = (props) => {
    const { classes } = this.props;
    return <TableEditColumn.Command className={classes.button} {...props} />;
  };

  componentDidMount = () => {
    this.getResults();
  };

  componentWillUnmount() {
    this.setState = (state, callback) => {
      return;
    };
  }

  getResults = () => {
    axios
      .get(getAllResults, { params: { jd_id: this.props.jdId } })
      .then((response) => {
        this.setState({
          isLoading: false,
          rows: response.data.map((item, index) => ({
            rank: `# ${index + 1}`,
            generatedScore: item.generated_score.toFixed(2),
            status: item.status,
            userName: item.user.name,
            email: item.user.email,
            contactNumber: item.user.contact_number,
          })),
        });
      })
      .catch((err) => {
        console.warn(err);
      });
  };
  searchChangeHandler = (value) => {
    this.setState({ searchText: value });
  };
  onSaveFile = () => {
    const data = JSON.stringify(this.state.rows);
    const blob = new Blob([data], { type: "application/json" });
    FileSaver.saveAs(
      blob,
      `ai-in-hr-data-${Math.random().toString(36).substring(7)}.json`
    );
  };

  render() {
    const { classes } = this.props;
    const { searchText } = this.state;
    return (
      <>
        <Paper className={classes.root}>
          {this.state.isLoading && (
            <Box p={25} align="center">
              <CircularProgress color="secondary" />
            </Box>
          )}
          {!this.state.isLoading && (
            <>
              <Grid rows={this.state.rows} columns={this.state.columns}>
                <SearchState
                  value={searchText}
                  onValueChange={this.searchChangeHandler}
                />
                <IntegratedFiltering />
                <SortingState
                  defaultSorting={[{ columnName: "rank", direction: "asc" }]}
                />
                <IntegratedSorting />
                <PagingState defaultCurrentPage={0} pageSize={10} />
                <IntegratedPaging />
                <EditingState onCommitChanges={() => {}} />
                <Table cellComponent={Cell} />
                <TableHeaderRow showSortingControls />
                <PagingPanel />
                <Toolbar />
                <ExportPanel startExport={this.onSaveFile} />
                <SearchPanel />
              </Grid>
            </>
          )}
        </Paper>
      </>
    );
  }
}

export default withStyles(useStyles)(JdTable);
