import { Button } from "@material-ui/core";
import { Card } from "@material-ui/core";
import { CardActions } from "@material-ui/core";
import { CardContent } from "@material-ui/core";
import {
  Box,
  Grid,
  Typography,
  withStyles,
  Dialog,
  TextField,
} from "@material-ui/core";
import axios from "axios";
import React, { Component } from "react";
import { getOneFeedback, updateFeedback } from "../../../utils/endPoints";
import * as dayjs from "dayjs";
import { Link } from "react-router-dom";
import { Tooltip } from "@material-ui/core";
import { IconButton } from "@material-ui/core";
import { Edit, Close } from "@material-ui/icons";
import { CardHeader } from "@material-ui/core";
import { Alert } from "@material-ui/lab";
import { DialogTitle } from "@material-ui/core";
import { DialogContent } from "@material-ui/core";
import { FormControlLabel } from "@material-ui/core";
import { Checkbox } from "@material-ui/core";

const useStyles = (theme) => ({
  closeButton: {
    position: "absolute",
    right: theme.spacing(1),
    top: theme.spacing(1),
  },
  formContainer: {
    padding: theme.spacing(0, 6, 6),
    [theme.breakpoints.down("sm")]: {
      padding: theme.spacing(0, 2, 3),
    },
  },
});
class FeedbackCard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      updateDialogOpen: false,
      wasHelpful: false,
      errorMessage: "",
      error: "",
      feedback: "",
      status: "",
      score: "",
    };
  }
  onChangeHandler = (e) => {
    if (e.target.value !== " ") {
      this.setState({
        [e.target.name]: e.target.value,
        error: false,
        errorMessage: "",
      });
    }
  };
  wasHelpfulHandler = () => {
    this.setState({
      wasHelpful: !this.state.wasHelpful,
      error: false,
      errorMessage: "",
    });
  };
  handleUpdateOpen = () => {
    axios
      .get(getOneFeedback, {
        params: {
          jd_id: this.props.app.jd.id,
          user_id: this.props.app.user.id,
        },
      })
      .then((response) => {
        this.setState({
          feedback: response.data.feedback,
          wasHelpful: response.data.was_useful,
          status: response.data.status,
          score: response.data.generated_score.toFixed(2),
          updateDialogOpen: true,
        });
      })
      .catch((err) => {
        console.warn(err);
      });
  };

  onUpdateHandler = (e) => {
    e.preventDefault();
    // send post request to endpoint to update result
    const data = {
      feedback: this.state.feedback,
      was_useful: this.state.wasHelpful,
    };
    axios
      .put(updateFeedback, data, {
        params: {
          jd_id: this.props.app.jd.id,
          user_id: this.props.app.user.id,
        },
      })
      .then(() => {
        this.handleUpdateClose();
        this.props.triggerUpdate();
      })
      .catch((err) => {
        console.warn(err);
        this.setState({
          error: true,
          errorMessage: "Something went wront, try again!",
        });
      });
  };

  handleUpdateClose = () => {
    this.setState({ updateDialogOpen: false });
  };
  render() {
    const { app, classes } = this.props;
    return (
      <Grid item xs={12}>
        <Card>
          <CardHeader
            action={
              <Box>
                <Tooltip title="Edit">
                  <IconButton
                    aria-label="edit"
                    onClick={() => {
                      this.handleUpdateOpen();
                    }}
                  >
                    <Edit />
                  </IconButton>
                </Tooltip>
              </Box>
            }
            title={app.user.name}
          />
          <CardContent>
            <Box mt={-2}>
              <Typography gutterBottom variant="subtitle1" component="h2">
                Message: {app.message}
              </Typography>
              <Typography gutterBottom variant="subtitle1" component="h2">
                Experience: {app.experience}
              </Typography>
              <Typography gutterBottom variant="subtitle1" component="h2">
                Email: {app.user.email}
              </Typography>
              <Typography gutterBottom variant="subtitle1" component="h2">
                Contact Number: {app.user.contact_number}
              </Typography>
              <Typography variant="caption" color="textSecondary" component="p">
                Applied on:{" "}
                {dayjs(app.created_at + "Z").format("ddd, MM : h:mm a")}
              </Typography>
            </Box>
          </CardContent>
          <CardActions>
            <Link to={`/hr/job-description/${app.jd.id}`} target="_blank">
              <Button size="small" color="secondary">
                View Job Description
              </Button>
            </Link>
          </CardActions>
        </Card>
        <Dialog
          open={this.state.updateDialogOpen}
          onClose={this.handleUpdateClose}
          fullWidth
        >
          <DialogTitle>
            <IconButton
              aria-label="close"
              className={classes.closeButton}
              onClick={this.handleUpdateClose}
            >
              <Close />
            </IconButton>
          </DialogTitle>
          <DialogContent>
            <form onSubmit={this.onUpdateHandler}>
              <Grid container spacing={2} className={classes.formContainer}>
                <Grid container spacing={2}>
                  {this.state.error && (
                    <Grid item xs={12}>
                      <Alert severity="error">{`${this.state.errorMessage}`}</Alert>
                    </Grid>
                  )}
                  <Grid item xs={12}>
                    <Alert
                      icon={false}
                      severity={
                        this.state.status === "POSITIVE"
                          ? "success"
                          : this.state.status === "---"
                          ? "info"
                          : "error"
                      }
                    >
                      <Typography gutterBottom variant="h6">
                        Score: {this.state.score}
                      </Typography>
                      <Typography gutterBottom variant="subtitle1">
                        Previous Feedback Status: {this.state.status}
                      </Typography>
                    </Alert>
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="feedback"
                      value={this.state.feedback}
                      onChange={this.onChangeHandler}
                      label="Feedback"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={this.state.wasHelpful}
                          name="wasHelpful"
                          color="primary"
                          onClick={() => {
                            this.wasHelpfulHandler();
                          }}
                        />
                      }
                      label="Score was helpful during the Interview"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Button
                      fullWidth
                      type="submit"
                      variant="contained"
                      color="primary"
                      disabled={this.state.error}
                    >
                      Update
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
            </form>
          </DialogContent>
        </Dialog>
      </Grid>
    );
  }
}

export default withStyles(useStyles)(FeedbackCard);
