import {
  Box,
  Button,
  CircularProgress,
  Container,
  Grid,
  Typography,
  withStyles,
  Dialog,
  IconButton,
  DialogTitle,
  DialogContent,
  TextField,
  Snackbar,
} from "@material-ui/core";
import { Alert } from "@material-ui/lab";
import { Add, Close } from "@material-ui/icons";
import axios from "axios";
import React, { Component } from "react";
import { addNewJdAPI, getJdByHrAPI } from "../../../utils/endPoints";
import { store } from "../../../redux/store";
import JdCard from "../JdCard/JdCard";
import Task from "../../../assets/task.svg";

const useStyles = (theme) => ({
  textBlue: {
    color: "#3495DB",
  },
  closeButton: {
    position: "absolute",
    right: theme.spacing(1),
    top: theme.spacing(1),
  },
  formContainer: {
    padding: theme.spacing(2, 6, 6),
    [theme.breakpoints.down("sm")]: {
      padding: theme.spacing(0, 2, 3),
    },
  },
  mainContainer: {
    padding: theme.spacing(0, 12, 0),
  },
  imageCenter: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  bodyImage: {
    padding: theme.spacing(0, 0, 5),
    height: "auto",
    width: "50%",
    [theme.breakpoints.down("sm")]: {
      height: "auto",
      width: "80%",
    },
  },
});

class ManageJd extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      showPostForm: false,
      deleteDialogOpen: false,
      updateDialogOpen: false,
      title: "",
      description: "",
      role: "",
      link: "",
      experience: "",
      location: "",
      openings: "",
      lastDate: "2021-12-01",
      error: false,
      errorMessage: "",
      success: false,
      updateSuccess: false,
      deleteSuccess: false,
      jds: [],
    };
  }
  componentDidMount() {
    this.getAllJd();
  }

  getAllJd = () => {
    this.setState({ isLoading: true });

    axios
      .get(getJdByHrAPI, {
        params: { hr_id: store.getState().auth.hrData.id },
      })
      .then((response) => {
        this.setState({ jds: response.data, isLoading: false });
      })
      .catch((err) => {
        console.warn(err);
      });
  };

  handleJdFormOpen = () => {
    this.setState({ showPostForm: true });
  };
  handleJdFormClose = () => {
    this.setState({ showPostForm: false });
  };

  onSubmitHandler = (e) => {
    e.preventDefault();
    // send post request to endpoint
    const data = {
      title: this.state.title,
      description: this.state.description,
      role: this.state.role,
      link: this.state.link,
      experience: this.state.experience,
      openings: this.state.openings,
      location: this.state.location,
      last_date: this.state.lastDate,
    };
    axios
      .post(addNewJdAPI, data, {
        params: {
          hr_id: store.getState().auth.hrData.id.toString(),
        },
      })
      .then((response) => {
        if (response.status === 201) {
          this.setState({
            success: true,
            title: "",
            description: "",
            role: "",
            link: "",
            experience: "",
            location: "",

            openings: "",
            lastDate: "",
          });
          this.handleJdFormClose();
          setTimeout(() => this.setState({ success: false }), 4000);
          this.getAllJd();
        }
      })
      .catch((err) => {
        this.setState({
          error: true,
          errorMessage: "Something went wront, try again!",
        });
      });
  };

  onChangeHandler = (e) => {
    if (e.target.value !== " ") {
      this.setState({
        [e.target.name]: e.target.value,
        error: false,
        errorMessage: "",
      });
    }
  };

  render() {
    const { classes } = this.props;
    return (
      <Box>
        <Snackbar
          open={this.state.success}
          anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
          autoHideDuration={5000}
          onClose={() => {}}
        >
          <Alert variant="filled" severity="success">
            Job Description Added Successfully
          </Alert>
        </Snackbar>
        <Snackbar
          open={this.state.updateSuccess}
          anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
          autoHideDuration={5000}
          onClose={() => {}}
        >
          <Alert variant="filled" severity="success">
            Job Description Updated Successfully
          </Alert>
        </Snackbar>
        <Snackbar
          open={this.state.deleteSuccess}
          anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
          autoHideDuration={5000}
          onClose={() => {}}
        >
          <Alert variant="filled" severity="error">
            Job Description Deleted Successfully
          </Alert>
        </Snackbar>
        <Container className={classes.mainContainer}>
          <Box>
            <Typography
              className={classes.textBlue}
              variant="h4"
              color="textPrimary"
              gutterBottom
            >
              {`Manage Job Descriptions`}
            </Typography>
          </Box>
          <Box mb={2} className={classes.root}>
            <Button
              startIcon={<Add />}
              variant="contained"
              color="secondary"
              onClick={this.handleJdFormOpen}
              fullWidth
            >
              Post new Job Application
            </Button>
          </Box>
          {!this.state.isLoading && this.state.jds.length === 0 && (
            <Box mt={15}>
              <Grid className={classes.imageCenter}>
                <img
                  src={Task}
                  alt="add-new-job"
                  className={classes.bodyImage}
                />
              </Grid>
              <Typography align="center" variant="body2" color="textSecondary">
                You have not added any jobs.
              </Typography>
            </Box>
          )}
          <Box m={2} align="center">
            {this.state.isLoading && <CircularProgress color="primary" />}
          </Box>
          <Box>
            {!this.state.isLoading && (
              <Grid container spacing={3}>
                {this.state.jds.map((jd) => (
                  <JdCard
                    key={jd.id}
                    jdDetails={jd}
                    triggerUpdate={() => {
                      this.getAllJd();
                      this.setState({
                        updateSuccess: true,
                      });
                      setTimeout(() => {
                        this.setState({ updateSuccess: false });
                      }, 4000);
                    }}
                    triggerDelete={() => {
                      this.getAllJd();
                      this.setState({ deleteSuccess: true });
                      setTimeout(
                        () => this.setState({ deleteSuccess: false }),
                        4000
                      );
                    }}
                  />
                ))}
              </Grid>
            )}
          </Box>
        </Container>
        <Dialog
          open={this.state.showPostForm}
          onClose={this.handleJdFormClose}
          fullWidth
        >
          <DialogTitle>
            <IconButton
              aria-label="close"
              className={classes.closeButton}
              onClick={this.handleJdFormClose}
            >
              <Close />
            </IconButton>
          </DialogTitle>
          <DialogContent>
            <Typography
              variant="subtitle1"
              color="primary"
              align="center"
              gutterBottom
            >
              {`Fill all required details and submit`}
            </Typography>
            <form onSubmit={this.onSubmitHandler}>
              <Grid container spacing={2} className={classes.formContainer}>
                <Grid container spacing={2}>
                  {this.state.error && (
                    <Grid item xs={12}>
                      <Alert severity="error">{`${this.state.errorMessage}`}</Alert>
                    </Grid>
                  )}
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="title"
                      value={this.state.title}
                      onChange={this.onChangeHandler}
                      label="Title"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="role"
                      multiline
                      rows={2}
                      rowsMax={2}
                      value={this.state.role}
                      onChange={this.onChangeHandler}
                      label="Job Role"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      multiline
                      rows={4}
                      rowsMax={8}
                      name="description"
                      value={this.state.description}
                      onChange={this.onChangeHandler}
                      label="Job Description"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="link"
                      value={this.state.link}
                      onChange={this.onChangeHandler}
                      label="Link"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="experience"
                      value={this.state.experience}
                      onChange={this.onChangeHandler}
                      label="Required Experience"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="openings"
                      value={this.state.openings}
                      onChange={this.onChangeHandler}
                      label="Number of Openings"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="location"
                      value={this.state.location}
                      onChange={this.onChangeHandler}
                      label="Location"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      id="date"
                      required
                      fullWidth
                      type="date"
                      onChange={this.onChangeHandler}
                      name="lastDate"
                      value={this.state.lastDate}
                      label="Last Date to Apply"
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Button
                      fullWidth
                      type="submit"
                      variant="contained"
                      color="primary"
                      disabled={this.state.error}
                    >
                      Submit
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
            </form>
          </DialogContent>
        </Dialog>
      </Box>
    );
  }
}

export default withStyles(useStyles)(ManageJd);
