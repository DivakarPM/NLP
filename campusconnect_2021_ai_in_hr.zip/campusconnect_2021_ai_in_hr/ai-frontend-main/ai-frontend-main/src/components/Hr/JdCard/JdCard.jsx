import {
  Box,
  CardContent,
  CardActions,
  Button,
  Card,
  Grid,
  Typography,
  withStyles,
  Dialog,
  CardHeader,
  IconButton,
  DialogTitle,
  DialogContent,
  TextField,
} from "@material-ui/core";
import { Alert } from "@material-ui/lab";
import { Close, Delete, Edit } from "@material-ui/icons";
import axios from "axios";
import React, { Component } from "react";
import { deleteJdAPI, updateJdAPI } from "../../../utils/endPoints";
import { store } from "../../../redux/store";
import { DialogContentText } from "@material-ui/core";
import { DialogActions } from "@material-ui/core";
import { Link } from "react-router-dom";
import * as dayjs from "dayjs";
import { Tooltip } from "@material-ui/core";
import { MenuItem } from "@material-ui/core";

const useStyles = (theme) => ({
  textBlue: {
    color: "#3495DB",
  },
  closeButton: {
    position: "absolute",
    right: theme.spacing(1),
    top: theme.spacing(1),
  },
  formContainer: {
    padding: theme.spacing(0, 6, 6),
    [theme.breakpoints.down("sm")]: {
      padding: theme.spacing(0, 2, 3),
    },
  },
});
class JdCard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      deleteDialogOpen: false,
      updateDialogOpen: false,
      error: false,
      errorMessage: "",
      title: this.props.jdDetails.title,
      description: this.props.jdDetails.description,
      role: this.props.jdDetails.role,
      link: this.props.jdDetails.link,
      experience: this.props.jdDetails.experience,
      location: this.props.jdDetails.location,
      openings: this.props.jdDetails.openings,
      lastDate: this.props.jdDetails.last_date,
      active: this.props.jdDetails.active ? 1 : 0,
    };
  }

  handleDeleteOpen = () => {
    this.setState({ deleteDialogOpen: true });
  };

  handleDeleteClose = () => {
    this.setState({ deleteDialogOpen: false });
  };

  handleUpdateOpen = () => {
    this.setState({ updateDialogOpen: true });
  };

  handleUpdateClose = () => {
    this.setState({ updateDialogOpen: false });
  };

  onChangeHandler = (e) => {
    if (e.target.value !== " ") {
      this.setState({
        [e.target.name]: e.target.value,
        error: false,
        errorMessage: "",
      });
    }
  };
  handleChange = (event) => {
    this.setState({
      active: event.target.value,
      error: false,
      errorMessage: "",
    });
  };
  onUpdateHandler = (e) => {
    e.preventDefault();
    // send post request to endpoint to update data
    const data = {
      title: this.state.title,
      description: this.state.description,
      role: this.state.role,
      link: this.state.link,
      experience: this.state.experience,
      openings: this.state.openings,
      location: this.state.location,
      last_date: this.state.lastDate,
      active: this.state.active,
    };
    axios
      .put(updateJdAPI + this.props.jdDetails.id, data, {
        params: {
          hr_id: store.getState().auth.hrData.id.toString(),
        },
      })
      .then(() => {
        this.handleUpdateClose();
        this.props.triggerUpdate();
      })
      .catch((err) => {
        console.warn(err);
        this.setState({
          error: true,
          errorMessage: "Something went wront, try again!",
        });
      });
  };

  onDeleteHandler = () => {
    axios
      .delete(deleteJdAPI + this.props.jdDetails.id, {
        params: { hr_id: store.getState().auth.hrData.id.toString() },
      })
      .then(() => {
        this.props.triggerDelete();
        this.handleDeleteClose();
      })
      .catch((err) => {
        console.warn(err);
      });
  };
  render() {
    const { classes, jdDetails } = this.props;
    return (
      <>
        <Grid item xs={12}>
          <Card>
            <CardHeader
              action={
                <Box>
                  <Tooltip title="Delete">
                    <IconButton
                      aria-label="delete"
                      onClick={() => {
                        this.handleDeleteOpen();
                      }}
                    >
                      <Delete />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Edit">
                    <IconButton
                      aria-label="edit"
                      onClick={() => {
                        this.handleUpdateOpen();
                      }}
                    >
                      <Edit />
                    </IconButton>
                  </Tooltip>
                </Box>
              }
              title={
                jdDetails.active
                  ? `${jdDetails.title}`
                  : `[INACTIVE] ${jdDetails.title}`
              }
            />
            <CardContent>
              <Box mt={-2}>
                <Typography ariant="subtitle1" gutterBottom>
                  {jdDetails.role}
                </Typography>
                <Typography ariant="subtitle1" gutterBottom>
                  Location: {jdDetails.location}
                </Typography>
                <Typography variant="body1" color="textSecondary" component="p">
                  Posted At:{" "}
                  {dayjs(jdDetails.posted_at + "Z").format("ddd, MM : h:mm a")}
                </Typography>
              </Box>
            </CardContent>
            <CardActions>
              <Link to={`/hr/job-description/${jdDetails.id}`} target="_blank">
                <Button size="small" color="secondary">
                  View Details
                </Button>
              </Link>
            </CardActions>
          </Card>
        </Grid>
        <Dialog
          open={this.state.updateDialogOpen}
          onClose={this.handleUpdateClose}
          fullWidth
        >
          <DialogTitle>
            <IconButton
              aria-label="close"
              className={classes.closeButton}
              onClick={this.handleUpdateClose}
            >
              <Close />
            </IconButton>
          </DialogTitle>
          <DialogContent>
            <form onSubmit={this.onUpdateHandler}>
              <Grid container spacing={2} className={classes.formContainer}>
                <Grid container spacing={2}>
                  {this.state.error && (
                    <Grid item xs={12}>
                      <Alert severity="error">{`${this.state.errorMessage}`}</Alert>
                    </Grid>
                  )}
                  <Grid item xs={12}>
                    <TextField
                      id="select-status"
                      select
                      required
                      fullWidth
                      margin="normal"
                      label="Status"
                      value={this.state.active}
                      onChange={this.handleChange}
                    >
                      <MenuItem value={1}>{`ACTIVE`}</MenuItem>
                      <MenuItem value={0}>{`INACTIVE`}</MenuItem>
                    </TextField>
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="title"
                      value={this.state.title}
                      onChange={this.onChangeHandler}
                      label="Title"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="role"
                      multiline
                      rows={2}
                      rowsMax={2}
                      value={this.state.role}
                      onChange={this.onChangeHandler}
                      label="Job Role"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      multiline
                      rows={3}
                      rowsMax={8}
                      name="description"
                      value={this.state.description}
                      onChange={this.onChangeHandler}
                      label="Job Description"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="link"
                      value={this.state.link}
                      onChange={this.onChangeHandler}
                      label="Link"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="experience"
                      value={this.state.experience}
                      onChange={this.onChangeHandler}
                      label="Required Experience"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="openings"
                      value={this.state.openings}
                      onChange={this.onChangeHandler}
                      label="Number of Openings"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="location"
                      value={this.state.location}
                      onChange={this.onChangeHandler}
                      label="Location"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      id="date"
                      required
                      fullWidth
                      type="date"
                      onChange={this.onChangeHandler}
                      name="lastDate"
                      value={this.state.lastDate}
                      label="Last Date to Apply"
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Button
                      fullWidth
                      type="submit"
                      variant="contained"
                      color="primary"
                      disabled={this.state.error}
                    >
                      Update
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
            </form>
          </DialogContent>
        </Dialog>
        <Dialog
          open={this.state.deleteDialogOpen}
          onClose={this.handleDeleteClose}
          fullWidth
        >
          <DialogTitle>{"Hold on!"}</DialogTitle>
          <DialogContent>
            <DialogContentText>
              Are you sure you want to Delete ?
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleDeleteClose} color="secondary">
              Cancel
            </Button>
            <Button onClick={this.onDeleteHandler} color="secondary" autoFocus>
              Confirm
            </Button>
          </DialogActions>
        </Dialog>
      </>
    );
  }
}

export default withStyles(useStyles)(JdCard);
