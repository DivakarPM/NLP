import {
  Box,
  CircularProgress,
  Container,
  Grid,
  Typography,
  withStyles,
} from "@material-ui/core";
import axios from "axios";
import React, { Component } from "react";
import { getApplicationsAPI } from "../../../utils/endPoints";
import ApplyJob from "../../../assets/job-offers.svg";
import FeedbackCard from "../FeedbackCard/FeedbackCard";
import SearchBar from "material-ui-search-bar";

const useStyles = (theme) => ({
  mainContainer: {
    padding: theme.spacing(0, 12, 0),
  },
  textBlue: {
    color: "#3495DB",
  },
  imageCenter: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  searchContainer: {
    position: "sticky",
    top: 100,
    bottom: 20,
    paddingBottom: theme.spacing(2),
    zIndex: 5,
  },
  searchBarFixed: {
    margin: theme.spacing(2, 0, 0),
    zIndex: 1,
    width: "100%",
    [theme.breakpoints.down("sm")]: {
      margin: theme.spacing(2, 2, 0),
    },
  },
  bodyImage: {
    padding: theme.spacing(0, 0, 5),
    height: "auto",
    width: "40%",
    [theme.breakpoints.down("sm")]: {
      height: "auto",
      width: "80%",
    },
  },
});
class ManageInt extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      applications: [],
      allResults: [],
      search: "",
    };
  }
  componentDidMount() {
    this.getAllApps();
  }

  getAllApps = () => {
    this.setState({ isLoading: true });

    axios
      .get(getApplicationsAPI)
      .then((response) => {
        this.setState({
          applications: response.data,
          allResults: response.data,
          isLoading: false,
        });
      })
      .catch((err) => {
        console.warn(err);
      });
  };

  searchUser = (text) => {
    if (text !== "") {
      this.setState({
        applications: this.state.allResults.filter(
          (data) =>
            data.user.name.toLowerCase().includes(text.toLowerCase()) ||
            data.user.email.toLowerCase().includes(text.toLowerCase()) ||
            data.user.address.toLowerCase().includes(text.toLowerCase())
        ),
      });
    } else {
      this.setState({ applications: this.state.allResults });
    }
  };
  render() {
    const { classes } = this.props;
    return (
      <Container className={classes.mainContainer}>
        <Box>
          <Typography
            className={classes.textBlue}
            variant="h4"
            color="textPrimary"
            gutterBottom
          >
            {`Feedbacks and Interview`}
          </Typography>
        </Box>
        <Box container className={classes.searchContainer}>
          <Box className={classes.searchBarFixed}>
            <SearchBar
              value={this.state.search}
              name="search"
              onChange={(value) => this.setState({ search: value })}
              placeholder={`Enter applicant's Email, Name, Address`}
              onRequestSearch={() => {
                this.searchUser(this.state.search);
              }}
            />
          </Box>
        </Box>
        {!this.state.isLoading && this.state.applications.length === 0 && (
          <Box mt={18}>
            <Grid className={classes.imageCenter}>
              <img
                src={ApplyJob}
                alt="applications"
                className={classes.bodyImage}
              />
            </Grid>
            <Typography align="center" variant="body2" color="textSecondary">
              No applications found.
            </Typography>
          </Box>
        )}
        <Box>
          <Box m={2} align="center">
            {this.state.isLoading && <CircularProgress color="primary" />}
          </Box>
          {!this.state.isLoading && (
            <Grid container spacing={3}>
              {this.state.applications.map((app) => (
                <FeedbackCard
                  key={app.id}
                  app={app}
                  triggerUpdate={() => {
                    this.getAllApps();
                  }}
                />
              ))}
            </Grid>
          )}
        </Box>
      </Container>
    );
  }
}

export default withStyles(useStyles)(ManageInt);
