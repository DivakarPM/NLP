import React, { Component } from "react";
import { Box, CircularProgress, Paper, withStyles } from "@material-ui/core";
import {
  Grid,
  Table,
  TableHeaderRow,
  PagingPanel,
  Toolbar,
  SearchPanel,
  ExportPanel,
} from "@devexpress/dx-react-grid-material-ui";
import {
  SearchState,
  IntegratedFiltering,
  PagingState,
  IntegratedPaging,
  SortingState,
  IntegratedSorting,
} from "@devexpress/dx-react-grid";
import FileSaver from "file-saver";
import axios from "axios";
import { store } from "../../../redux/store";
import { getJdByHrAPI, jdCountAPI } from "../../../utils/endPoints";

const useStyles = (theme) => ({
  root: {
    marginTop: theme.spacing(3),
  },
});

class SumTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      counts: [],
      rows: [],
      columns: [
        { name: "title", title: "Job Title" },
        { name: "currentCount", title: "Current Applications" },
        { name: "openCount", title: "Openings" },
        { name: "lastDate", title: "Last Date" },
      ],
      tableColumnExtensions: [
        { columnName: "title", align: "left" },
        { columnName: "currentCount", align: "center" },
        { columnName: "openCount", align: "center" },
        { columnName: "lastDate", align: "left" },
      ],
    };
  }

  componentWillUnmount() {
    this.setState = (state, callback) => {
      return;
    };
  }

  componentDidMount() {
    this.getAllJd();
  }
  getCountWithJdId = (jdId) => {
    for (var i = 0; i < this.state.counts.length; i++) {
      if (this.state.counts[i]["jd_id"] === jdId) {
        return this.state.counts[i]["count"];
      }
    }
    return 0;
  };
  getAllJd = () => {
    this.setState({ isLoading: true });
    axios
      .get(jdCountAPI)
      .then((response) => {
        this.setState({ counts: response.data, isLoading: false });
        axios
          .get(getJdByHrAPI, {
            params: { hr_id: store.getState().auth.hrData.id },
          })
          .then((response) => {
            this.setState({
              isLoading: false,
              rows: response.data.map((item) => ({
                title: item.title,
                currentCount: this.getCountWithJdId(item.id),
                openCount: item.openings,
                lastDate: item.last_date,
              })),
            });
          })
          .catch((err) => {
            console.warn(err);
          });
      })
      .catch((err) => {
        console.warn(err);
      });
  };
  onSaveFile = () => {
    const data = JSON.stringify(this.state.rows);
    const blob = new Blob([data], { type: "application/json" });
    FileSaver.saveAs(
      blob,
      `ai-in-hr-data-${Math.random().toString(36).substring(7)}.json`
    );
  };

  render() {
    const { classes } = this.props;
    const { searchText } = this.state;
    return (
      <>
        <Paper className={classes.root}>
          {this.state.isLoading && (
            <Box p={25} align="center">
              <CircularProgress color="secondary" />
            </Box>
          )}
          {!this.state.isLoading && (
            <>
              <Grid rows={this.state.rows} columns={this.state.columns}>
                <SearchState
                  value={searchText}
                  onValueChange={this.searchChangeHandler}
                />
                <IntegratedFiltering />
                <SortingState
                  defaultSorting={[{ columnName: "num", direction: "asc" }]}
                />
                <IntegratedSorting />
                <PagingState defaultCurrentPage={0} pageSize={10} />
                <IntegratedPaging />
                <Table columnExtensions={this.state.tableColumnExtensions} />
                <TableHeaderRow showSortingControls />
                <PagingPanel />
                <Toolbar />
                <ExportPanel startExport={this.onSaveFile} />
                <SearchPanel />
              </Grid>
            </>
          )}
        </Paper>
      </>
    );
  }
}

export default withStyles(useStyles)(SumTable);
