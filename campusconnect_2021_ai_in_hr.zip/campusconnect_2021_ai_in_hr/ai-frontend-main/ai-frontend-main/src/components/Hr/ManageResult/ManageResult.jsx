import {
  Box,
  CircularProgress,
  Container,
  Grid,
  Typography,
  withStyles,
} from "@material-ui/core";
import React, { Component } from "react";
import SumTable from "../SumTable/SumTable";

const useStyles = (theme) => ({
  mainContainer: {
    padding: theme.spacing(0, 12, 0),
  },
  textBlue: {
    color: "#3495DB",
  },
});
class ManageResult extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  render() {
    const { classes } = this.props;
    return (
      <Container className={classes.mainContainer}>
        <Box>
          <Typography
            className={classes.textBlue}
            variant="h4"
            color="textPrimary"
            gutterBottom
          >
            {`Summary of Jobs`}
          </Typography>
        </Box>
        <Box m={2} align="center">
          {this.state.isLoading && <CircularProgress color="primary" />}
        </Box>
        <Grid className={classes.root}>
          <SumTable />
        </Grid>
      </Container>
    );
  }
}

export default withStyles(useStyles)(ManageResult);
