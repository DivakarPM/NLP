import { Typography, Box } from "@material-ui/core";
import React from "react";

function Copyright() {
  return (
    <Box mt={2} mb={2}>
      <Typography variant="body2" color="textSecondary" align="center">
        {"Copyright © Unisys 2021"}
      </Typography>
    </Box>
  );
}
export default Copyright;
