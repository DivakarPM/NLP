import React, { Component } from "react";
import { store } from "../../../redux/store";
import { logout } from "../../../redux/auth/auth.actions";
import { Redirect } from "react-router-dom";
class Logout extends Component {
  componentDidMount() {
    store.dispatch(logout());
  }
  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }
  render() {
    return <Redirect to="/" />;
  }
}
export default Logout;
