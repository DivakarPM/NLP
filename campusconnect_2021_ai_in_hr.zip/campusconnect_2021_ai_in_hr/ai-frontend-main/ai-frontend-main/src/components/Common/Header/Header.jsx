import React, { Component } from "react";
import AppBar from "@material-ui/core/AppBar";
import Button from "@material-ui/core/Button";
import Toolbar from "@material-ui/core/Toolbar";
import {
  Box,
  Grid,
  IconButton,
  SwipeableDrawer,
  Hidden,
  Tooltip,
  MenuItem,
  Menu,
  Typography,
} from "@material-ui/core";
import { Link, withRouter } from "react-router-dom";
import { withStyles } from "@material-ui/core/styles";
import { Close, AccountCircle } from "@material-ui/icons";
import MenuIcon from "@material-ui/icons/Menu";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";

const useStyles = (theme) => ({
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
  },
  toolbarHeader: {
    flexWrap: "wrap",
  },
  toolbarLogo: {
    flexGrow: 1,
    display: "flex",
    alignItems: "center",
    height: "55px",
    width: "auto",
    [theme.breakpoints.down("sm")]: {
      height: "45px",
    },
  },

  toolbarDashboard: {
    flexGrow: 1,
    display: "flex",
    alignItems: "center",
    height: "55px",
    width: "auto",
    [theme.breakpoints.down("sm")]: {
      display: "flex",
      justifyContent: "flex-start",
      height: "45px",
    },
  },
  link: {
    margin: theme.spacing(1, 1),
    color: "#FFFF",
  },
  activeLink: {
    margin: theme.spacing(1, 1),
    color: theme.palette.secondary.main,
    [theme.breakpoints.down("sm")]: {
      display: "none",
    },
  },
  mobileActive: {
    color: theme.palette.primary.main,
  },
  buttonLink: {
    margin: theme.spacing(1, 1),
  },
  menu: {
    [theme.breakpoints.up("md")]: {
      display: "none",
    },
  },

  drawer: {
    width: 400,
  },
  drawerGrid: {
    display: "flex",
    alignItems: "center",
    flexDirection: "column",
    justifyContent: "center",
    padding: theme.spacing(2, 8, 2),
    marginTop: theme.spacing(10),
  },
  drawerButtons: {
    margin: theme.spacing(1, 0, 1),
  },
  closeButton: {
    position: "absolute",
    top: 6,
    right: 18,
  },
});

class Header extends Component {
  constructor(props) {
    super(props);
    this.state = {
      right: false,
      open: false,
      menuOpen: false,
    };
  }

  static propTypes = {
    isAuth: PropTypes.bool,
    auth: PropTypes.object,
    type: PropTypes.string,
  };
  handleClickOpen = () => {
    this.setState({ open: true });
  };

  handleClose = () => {
    this.setState({ open: false });
  };
  handleMenuOpen = () => {
    this.setState({ menuOpen: true });
  };

  handleMenuClose = () => {
    this.setState({ menuOpen: false });
  };
  toggleDrawer = (anchor, open) => (event) => {
    if (
      event &&
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }
    this.setState({ ...this.state, [anchor]: open });
  };
  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }
  render() {
    const { classes } = this.props;

    return (
      <AppBar
        position={this.props.position}
        color={this.props.color}
        elevation={0}
        className={classes.appBar}
      >
        <Toolbar className={classes.toolbarHeader}>
          <Box
            className={
              this.props.location.pathname === "/dashboard"
                ? classes.toolbarDashboard
                : classes.toolbarLogo
            }
          >
            <Link to="/">
              <Typography
                variant="h6"
                color="secondary"
                className={classes.link}
              >
                AI in HR
              </Typography>
            </Link>
          </Box>

          <nav>
            <Hidden smDown>
              {!this.props.isAuth && (
                <Link to="/signin">
                  <Button
                    variant="contained"
                    color="secondary"
                    className={classes.buttonLink}
                  >
                    Sign in / Up
                  </Button>
                </Link>
              )}
            </Hidden>
          </nav>
          <Dialog open={this.state.open} onClose={this.handleClose} fullWidth>
            <DialogTitle>{"Hold on!"}</DialogTitle>
            <DialogContent>
              <DialogContentText>
                Are you sure you want to Logout ?
              </DialogContentText>
            </DialogContent>
            <DialogActions>
              <Button onClick={this.handleClose} color="secondary">
                Cancel
              </Button>
              <Link to="/logout">
                <Button onClick={this.handleClose} color="secondary" autoFocus>
                  Confirm
                </Button>
              </Link>
            </DialogActions>
          </Dialog>
          <SwipeableDrawer
            anchor={"right"}
            open={this.state["right"]}
            onClose={this.toggleDrawer("right", false)}
            onOpen={this.toggleDrawer("right", true)}
            className={classes.drawer}
          >
            <Grid container spacing={0} className={classes.drawerGrid}>
              <IconButton
                aria-label="go-back"
                className={classes.closeButton}
                onClick={this.toggleDrawer("right", false)}
              >
                <Close color="primary" />
              </IconButton>

              {!this.props.isAuth && (
                <Grid item xs={12} className={classes.drawerButtons}>
                  <Link to="/signin">
                    <Button
                      color="primary"
                      variant="contained"
                    >{`Sign In`}</Button>
                  </Link>
                </Grid>
              )}
              {!this.props.isAuth && (
                <Grid item xs={12} className={classes.drawerButtons}>
                  <Link to="/dashboard">
                    <Button
                      color="primary"
                      variant="outlined"
                    >{`Sign Up`}</Button>
                  </Link>
                </Grid>
              )}
              {this.props.isAuth && (
                <Grid item xs={12} className={classes.drawerButtons}>
                  <Link to="/">
                    <Button
                      className={
                        this.props.location.pathname === "/"
                          ? classes.mobileActive
                          : ""
                      }
                    >
                      {`Home`}
                    </Button>
                  </Link>
                </Grid>
              )}
              {this.props.isAuth && (
                <Grid item xs={12} className={classes.drawerButtons}>
                  <Link to="/dashboard">
                    <Button
                      className={
                        this.props.location.pathname === "/dashboard"
                          ? classes.mobileActive
                          : ""
                      }
                    >
                      {`My Dashboard`}
                    </Button>
                  </Link>
                </Grid>
              )}

              {this.props.isAuth && (
                <Grid item xs={12} className={classes.drawerButtons}>
                  <Button
                    variant="outlined"
                    color="primary"
                    onClick={this.handleClickOpen}
                  >
                    Logout
                  </Button>
                </Grid>
              )}
            </Grid>
          </SwipeableDrawer>
          {this.props.isAuth && (
            <Hidden smDown>
              <Typography
                variant="h6"
                className={classes.link}
                onClick={this.handleMenuOpen}
              >
                {this.props.type === "hr"
                  ? this.props.auth.hrData.email
                  : this.props.auth.userData.email}
              </Typography>
              <div>
                <Tooltip title="More">
                  <IconButton
                    aria-label="account of current user"
                    aria-controls="menu-appbar"
                    aria-haspopup="true"
                    onClick={this.handleMenuOpen}
                    className={classes.link}
                  >
                    <AccountCircle />
                  </IconButton>
                </Tooltip>
                <Menu
                  style={{ marginBottom: 20 }}
                  id="menu-appbar"
                  anchorEl={this.state.menuOpen}
                  getContentAnchorEl={null}
                  anchorOrigin={{ vertical: "top", horizontal: "right" }}
                  transformOrigin={{ vertical: "bottom", horizontal: "right" }}
                  open={this.state.menuOpen}
                  onClose={this.handleMenuClose}
                  PaperProps={{
                    style: {
                      marginTop: 45,
                    },
                  }}
                >
                  {this.props.isAuth && (
                    <div>
                      <Link to="/">
                        <MenuItem
                          selected={this.props.location.pathname === "/"}
                          onClick={this.handleMenuClose}
                        >
                          <Typography variant="button" color="textSecondary">
                            {`Home`}
                          </Typography>
                        </MenuItem>
                      </Link>
                      <Link to="/dashboard">
                        <MenuItem
                          selected={
                            this.props.location.pathname === "/dashboard"
                          }
                          onClick={this.handleMenuClose}
                        >
                          <Typography variant="button" color="textSecondary">
                            {`My Dashboard`}
                          </Typography>
                        </MenuItem>
                      </Link>

                      <MenuItem
                        selected={this.props.location.pathname === "/logout"}
                        onClick={this.handleClickOpen}
                      >
                        <Typography variant="button" color="textSecondary">
                          Logout
                        </Typography>
                      </MenuItem>
                    </div>
                  )}
                </Menu>
              </div>
            </Hidden>
          )}
          <Tooltip title="Menu">
            <IconButton
              aria-label="menu-web"
              className={classes.menu}
              onClick={this.toggleDrawer("right", true)}
            >
              <MenuIcon color="secondary" />
            </IconButton>
          </Tooltip>
        </Toolbar>
      </AppBar>
    );
  }
}
const mapStateToProps = (state) => ({
  isAuth: state.auth.isAuth,
  auth: state.auth,
  type: state.auth.type,
});

export default connect(mapStateToProps)(
  withStyles(useStyles)(withRouter(Header))
);
