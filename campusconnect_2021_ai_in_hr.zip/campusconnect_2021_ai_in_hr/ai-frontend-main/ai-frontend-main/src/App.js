import React from "react";
import "./App.css";
import { Route, Switch } from "react-router";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import PrivateRoute from "./components/Common/PrivateRoute";
import NoMatch from "./pages/NoMatch/NoMatch";
import Logout from "./components/Common/Logout/Logout";
import Signin from "./pages/Signin/Signin";
import Home from "./pages/Home/Home";
import Signup from "./pages/Signup/Signup";
import Dashboard from "./pages/Dashboard/Dashboard";
import AllJdPage from "./pages/AllJdPage/AllJdPage";
import FullJdDetails from "./pages/FullJdDetails/FullJdDetails";
import FullJdDetailsHR from "./pages/FullJdDetailsHR/FullJdDetailsHR";
import KnowMore from "./pages/KnowMore/KnowMore";

class App extends React.Component {
  static propTypes = {
    isAuth: PropTypes.bool,
  };
  componentDidMount() {}
  render() {
    return (
      <Switch>
        <Route exact path="/" component={Home} />
        <Route exact path="/about" component={KnowMore} />
        <Route exact path="/signin" component={Signin} />
        <Route exact path="/signup" component={Signup} />
        <PrivateRoute exact path="/dashboard" component={Dashboard} />
        <PrivateRoute exact path="/jobs" component={AllJdPage} />
        <PrivateRoute
          exact
          path="/job-description/:id"
          component={FullJdDetails}
        />
        <PrivateRoute
          exact
          path="/hr/job-description/:id"
          component={FullJdDetailsHR}
        />
        <Route exact path="/logout" component={Logout} />
        <Route component={NoMatch} />
      </Switch>
    );
  }
}

const mapStateToProps = (state) => ({
  isAuth: state.auth.isAuth,
});

export default connect(mapStateToProps)(App);
