import React from "react";
import { createMount } from "@material-ui/core/test-utils";
import { Provider } from "react-redux";
import { persistor, store } from "./redux/store";
import { BrowserRouter } from "react-router-dom";
import { PersistGate } from "redux-persist/integration/react";
import ScrollToTop from "./utils/ScrollToTop";
import App from "./App";

describe("Application render without crash", () => {
  let mount;

  beforeAll(() => {
    mount = createMount();
  });

  afterAll(() => {
    mount.cleanUp();
  });

  it("should render full app", () => {
    const wrapper = mount(
      <Provider store={store}>
        <BrowserRouter>
          <PersistGate persistor={persistor}>
            <ScrollToTop>
              <App />
            </ScrollToTop>
          </PersistGate>
        </BrowserRouter>
      </Provider>
    );
    expect(wrapper).toBeTruthy();
  });
});
