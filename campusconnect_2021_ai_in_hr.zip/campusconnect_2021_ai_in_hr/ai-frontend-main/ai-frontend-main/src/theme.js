import { createMuiTheme } from "@material-ui/core/styles";

// A custom theme for this app
const theme = createMuiTheme({
  palette: {
    primary: {
      light: "#333333",
      main: "#000",
      dark: "#000000",
    },
    secondary: {
      light: "#d85b6b",
      main: "#CF3246",
      dark: "#902331",
    },
    background: {
      main: "#eee",
    },
  },
  typography: {
    fontFamily: "'Work Sans', sans-serif",
    button: {
      fontWeight: 600,
      fontSize: 16,
      letterSpacing: 1,
    },
  },
});

export default theme;
