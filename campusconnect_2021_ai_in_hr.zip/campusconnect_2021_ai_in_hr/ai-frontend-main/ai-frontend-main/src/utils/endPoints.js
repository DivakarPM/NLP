const baseUrl = "https://ai-in-hr.herokuapp.com/";
// const baseUrl = "http://127.0.0.1:5000/";

// common
export const signinUserAPI = `${baseUrl}/api/signin/user`;
export const signinHrAPI = `${baseUrl}/api/signin/hr`;
export const signupUserAPI = `${baseUrl}/api/signup/user`;
export const signupHrAPI = `${baseUrl}/api/signup/hr`;

// hr
export const addNewJdAPI = `${baseUrl}/api/hr/job-description`;
export const getAllJdAPI = `${baseUrl}/api/job-description/all`;
export const getJdByIdAPI = `${baseUrl}/api/job-description/`;
export const getJdByHrAPI = `${baseUrl}/api/hr/job-description`;
export const updateJdAPI = `${baseUrl}/api/hr/update/job-description/`;
export const deleteJdAPI = `${baseUrl}/api/hr/delete/job-description/`;
export const getAppByJd = `${baseUrl}/api/application`;
export const getApplicationsAPI = `${baseUrl}/api/application/all`;

// result
export const getAllResults = `${baseUrl}/api/hr/results`;
export const getOneFeedback = `${baseUrl}/api/hr/get-result`;
export const updateFeedback = `${baseUrl}/api/hr/update/result`;

// user
export const getAppById = `${baseUrl}/api/user/application`;
export const applyForJd = `${baseUrl}/api/user/apply`;

// resume
export const getUserResume = `${baseUrl}/api/user/resume`;
export const getResumeById = `${baseUrl}/api/resume`;
export const downloadResume = `${baseUrl}/api/resume/download`;
export const uploadResume = `${baseUrl}/api/resume/upload`;
export const deleteResume = `${baseUrl}/api/delete/resume/`;

// dashboard
export const userCountAPI = `${baseUrl}/api/count/user`;
export const hrCountAPI = `${baseUrl}/api/count/hr`;
export const jdCountAPI = `${baseUrl}/api/count/jd`;
