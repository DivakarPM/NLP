export const dashBoardHrSideMenu = [
  {
    id: 0,
    name: "Dashboard",
  },
  {
    id: 1,
    name: "Job Descriptions",
  },
  {
    id: 2,
    name: "Feedbacks",
  },
];

export const dashBoardUserSideMenu = [
  {
    id: 0,
    name: "My Applications",
  },
  {
    id: 1,
    name: "My Resume",
  },
];
