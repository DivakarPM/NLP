import { Container, Hidden, Typography } from "@material-ui/core";
import React, { Component } from "react";
import { withStyles } from "@material-ui/core/styles";
import Header from "../../components/Common/Header/Header";
import Drawer from "@material-ui/core/Drawer";
import CssBaseline from "@material-ui/core/CssBaseline";
import Toolbar from "@material-ui/core/Toolbar";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import {
  Timeline,
  Description,
  AllInbox,
  Work,
  Feedback,
} from "@material-ui/icons";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { Helmet } from "react-helmet";
import {
  dashBoardHrSideMenu,
  dashBoardUserSideMenu,
} from "../../utils/staticTexts";
import ManageJd from "../../components/Hr/ManageJd/ManageJd";
import ManageResult from "../../components/Hr/ManageResult/ManageResult";
import ManageResume from "../../components/User/ManageResume/ManageResume";
import ManageApplication from "../../components/User/ManageApplication/ManageApplication";
import ManageInt from "../../components/Hr/ManageInt/ManageInt";

var drawerWidth = 260;
const useStyles = (theme) => ({
  root: {
    display: "flex",
  },

  appBar: {
    zIndex: theme.zIndex.drawer + 1,
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    marginTop: theme.spacing(10),
    whiteSpace: "nowrap",
    [theme.breakpoints.down("sm")]: {
      width: 370,
    },
  },

  drawerPaper: {
    width: drawerWidth,
    marginTop: theme.spacing(1),
    [theme.breakpoints.down("sm")]: {
      width: 370,
    },
  },
  drawerContainer: {
    overflow: "auto",
  },
  toolbar: {
    padding: theme.spacing(7, 0),
  },
  content: {
    flexGrow: 1,
    overflow: "hidden",
    paddingTop: theme.spacing(4),
  },
});

class Dashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      mobileOpen: false,
      showMe: 0,
      open: false,
    };
  }
  static propTypes = {
    isAuth: PropTypes.bool,
    type: PropTypes.string,
  };
  handleClickOpen = () => {
    this.setState({ open: true });
  };

  handleClose = () => {
    this.setState({ open: false });
  };

  show = (index) => {
    //go home
    if (index === 5) {
      this.props.history.push("/");
    }
    this.setState({ showMe: index });
  };

  handleLogout = () => {
    this.props.history.push("/logout");
  };
  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }
  render() {
    const { classes } = this.props;
    return (
      <>
        <Helmet>
          <title>Dashboard | AI in HR</title>
        </Helmet>
        <Header />
        <Container>
          <div className={classes.root}>
            <CssBaseline />
            <Hidden smDown>
              <Drawer
                className={classes.drawer}
                variant="permanent"
                classes={{
                  paper: classes.drawerPaper,
                }}
              >
                <Toolbar />
                <div className={classes.drawerContainer}>
                  {this.props.type !== "user" && (
                    <List>
                      {dashBoardHrSideMenu.map((text, index) => (
                        <ListItem
                          button
                          key={text.id}
                          selected={index === this.state.showMe}
                          onClick={() => this.show(index)}
                        >
                          <ListItemIcon>
                            {index === 0 ? (
                              <Timeline />
                            ) : index === 1 ? (
                              <Work />
                            ) : index === 2 ? (
                              <Feedback />
                            ) : null}
                          </ListItemIcon>
                          <ListItemText
                            primary={
                              <Typography
                                variant="button"
                                color="textSecondary"
                              >
                                {text.name}
                              </Typography>
                            }
                            color="primary"
                          />
                        </ListItem>
                      ))}
                    </List>
                  )}
                  {this.props.type === "user" && (
                    <List>
                      {dashBoardUserSideMenu.map((text, index) => (
                        <ListItem
                          button
                          key={text.id}
                          selected={index === this.state.showMe}
                          onClick={() => this.show(index)}
                        >
                          <ListItemIcon>
                            {index === 0 ? (
                              <AllInbox color="textPrimary" />
                            ) : index === 1 ? (
                              <Description color="textPrimary" />
                            ) : null}
                          </ListItemIcon>
                          <ListItemText
                            primary={
                              <Typography
                                variant="button"
                                color="textSecondary"
                              >
                                {text.name}
                              </Typography>
                            }
                            color="primary"
                          />
                        </ListItem>
                      ))}
                    </List>
                  )}
                </div>
              </Drawer>
            </Hidden>

            {this.props.type !== "user" ? (
              <main className={classes.content}>
                <div className={classes.toolbar}>
                  {this.state.showMe === 0 ? (
                    <ManageResult />
                  ) : this.state.showMe === 1 ? (
                    <ManageJd />
                  ) : this.state.showMe === 2 ? (
                    <ManageInt />
                  ) : (
                    <ManageResult />
                  )}
                </div>
              </main>
            ) : (
              <main className={classes.content}>
                <div className={classes.toolbar}>
                  {this.state.showMe === 0 ? (
                    <ManageApplication />
                  ) : this.state.showMe === 1 ? (
                    <ManageResume />
                  ) : (
                    <ManageResume />
                  )}
                </div>
              </main>
            )}
          </div>
        </Container>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  isAuth: state.auth.isAuth,
  type: state.auth.type,
});
export default connect(mapStateToProps)(withStyles(useStyles)(Dashboard));
