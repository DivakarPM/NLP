import React, { Component } from "react";
import { Box, Button, Container, Link, Typography } from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";
import PropTypes from "prop-types";
import useScrollTrigger from "@material-ui/core/useScrollTrigger";
import Fab from "@material-ui/core/Fab";
import KeyboardArrowUpIcon from "@material-ui/icons/KeyboardArrowUp";
import Zoom from "@material-ui/core/Zoom";
import Header from "../../components/Common/Header/Header";
import { Helmet } from "react-helmet";
import axios from "axios";
import { applyForJd, getJdByIdAPI } from "../../utils/endPoints";
import { Paper } from "@material-ui/core";
import * as dayjs from "dayjs";
import { Dialog } from "@material-ui/core";
import { DialogTitle } from "@material-ui/core";
import { IconButton } from "@material-ui/core";
import { Close } from "@material-ui/icons";
import { DialogContent } from "@material-ui/core";
import { Grid } from "@material-ui/core";
import { TextField } from "@material-ui/core";
import { Alert } from "@material-ui/lab";
import { store } from "../../redux/store";
import { Snackbar } from "@material-ui/core";
import { LinearProgress } from "@material-ui/core";

const useStyles = (theme) => ({
  root: {
    marginTop: theme.spacing(16),
  },
  heroContent: {
    padding: theme.spacing(0, 10, 2),
  },
  textBlue: {
    color: "#3495DB",
  },
  backToTop: {
    position: "fixed",
    bottom: theme.spacing(2),
    right: theme.spacing(2),
  },
  greyColor: {
    color: "grey",
  },
  descriptionPaper: {
    padding: theme.spacing(6, 10, 6),
  },
  closeButton: {
    position: "absolute",
    right: theme.spacing(1),
    top: theme.spacing(1),
  },
  formContainer: {
    padding: theme.spacing(4, 6, 6),
    [theme.breakpoints.down("sm")]: {
      padding: theme.spacing(0, 2, 3),
    },
  },
});

function ScrollTop(props) {
  const { children, window, classes } = props;
  const trigger = useScrollTrigger({
    target: window ? window() : undefined,
    disableHysteresis: true,
    threshold: 100,
  });

  const handleClick = (event) => {
    const anchor = (event.target.ownerDocument || document).querySelector(
      "#back-to-top-anchor"
    );

    if (anchor) {
      anchor.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  };

  return (
    <Zoom in={trigger}>
      <div
        onClick={handleClick}
        role="presentation"
        className={classes.backToTop}
      >
        {children}
      </div>
    </Zoom>
  );
}
ScrollTop.propTypes = {
  children: PropTypes.element.isRequired,
  window: PropTypes.func,
};
class FullJdDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      loading: false,
      title: "",
      description: "",
      role: "",
      link: "",
      experience: "",
      openings: "",
      lastDate: "",
      active: "",
      postedAt: "",
      postedBy: "",
      location: "",
      message: "",
      myExperience: "",
      errorMessage: "",
      error: false,
      showApplyForm: false,
    };
  }

  componentDidMount() {
    this.getJob();
  }

  getJob = () => {
    this.setState({ isLoading: true });
    axios
      .get(getJdByIdAPI + this.props.match.params.id)
      .then((response) => {
        this.setState({
          title: response.data.title,
          description: response.data.description,
          role: response.data.role,
          link: response.data.link,
          experience: response.data.experience,
          openings: response.data.openings,
          lastDate: response.data.last_date,
          active: response.data.active,
          location: response.data.location,
          postedAt: response.data.posted_at,
          postedBy: response.data.posted_by.name,
          isLoading: false,
        });
      })
      .catch((err) => {
        console.warn(err);
      });
  };
  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }

  onSubmitHandler = (e) => {
    e.preventDefault();
    // send post request to endpoint
    this.setState({ loading: true });
    const data = {
      message: this.state.message,
      experience: this.state.myExperience,
    };
    axios
      .post(applyForJd, data, {
        params: {
          user_id: store.getState().auth.userData.id.toString(),
          jd_id: this.props.match.params.id.toString(),
        },
      })
      .then((response) => {
        if (response.status === 201) {
          this.setState({
            success: true,
            loading: false,
            message: "",
            myExperience: "",
          });
          this.handleApplyFormClose();
          setTimeout(() => this.setState({ success: false }), 4000);
        }
      })
      .catch((err) => {
        this.setState({
          error: true,
          loading: false,
          errorMessage: err.response.data.error,
        });
      });
  };
  handleApplyFormOpen = () => {
    this.setState({ showApplyForm: true, message: "", myExperience: "" });
  };
  handleApplyFormClose = () => {
    this.setState({ showApplyForm: false });
  };
  onChangeHandler = (e) => {
    if (e.target.value !== " ") {
      this.setState({
        [e.target.name]: e.target.value,
        error: false,
        errorMessage: "",
      });
    }
  };
  render() {
    const { classes } = this.props;
    const {
      title,
      description,
      role,
      link,
      lastDate,
      openings,
      experience,
      location,
      postedAt,
    } = this.state;
    return (
      <>
        <Helmet>
          <title>Job Details | AI in HR</title>
        </Helmet>
        <Header />
        <div id="back-to-top-anchor" />
        <Snackbar
          open={this.state.success}
          anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
          autoHideDuration={5000}
          onClose={() => {}}
        >
          <Alert variant="filled" severity="success">
            Application Sent
          </Alert>
        </Snackbar>
        {!this.state.isLoading && (
          <Container className={classes.root}>
            <Box className={classes.heroContent}>
              <Container>
                <Paper className={classes.descriptionPaper}>
                  <Box>
                    <Typography gutterBottom variant="h4">
                      {title}
                    </Typography>
                    <Typography variant="h6" color="textPrimary" gutterBottom>
                      <Box fontWeight="600">Role</Box>
                      <Box fontWeight="400">{role}</Box>
                    </Typography>
                    <Typography variant="h6" color="textPrimary" gutterBottom>
                      <Box fontWeight="600">Location</Box>
                      <Box fontWeight="400">{location}</Box>
                    </Typography>
                    <Typography variant="h6" color="textPrimary" component="p">
                      <Box fontWeight="600">Posted On</Box>{" "}
                      <Box fontWeight="400">
                        {dayjs(postedAt).format("DD/MM/YYYY")}
                      </Box>
                    </Typography>
                    <Typography variant="h6" color="textPrimary" component="p">
                      <Box fontWeight="600">Last Date to Apply</Box>{" "}
                      <Box fontWeight="400">
                        {dayjs(lastDate).format("DD/MM/YYYY")}
                      </Box>
                    </Typography>
                    <Typography variant="h6" color="textPrimary" gutterBottom>
                      <Box fontWeight="600">Minimum Experience</Box>
                      <Box fontWeight="400">{experience} year/s</Box>
                    </Typography>
                    <Typography variant="h6" color="textPrimary" gutterBottom>
                      <Box fontWeight="600">Openings</Box>
                      <Box fontWeight="400">{openings}</Box>
                    </Typography>
                    <Typography variant="h6" color="textPrimary" gutterBottom>
                      <Box fontWeight="600">Job Description</Box>
                    </Typography>
                    {description.split("\n").map((line) => (
                      <Typography
                        variant="body1"
                        color="textPrimary"
                        gutterBottom
                      >
                        <Box fontWeight="400">{line}</Box>
                      </Typography>
                    ))}

                    <Link
                      href={link}
                      target="_blank"
                      variant="h6"
                      className={classes.textBlue}
                    >
                      {link}
                    </Link>
                  </Box>
                  <Box mt={4}>
                    <Button
                      variant="contained"
                      color="secondary"
                      onClick={this.handleApplyFormOpen}
                    >
                      Apply Now
                    </Button>
                  </Box>
                </Paper>
              </Container>
            </Box>
          </Container>
        )}

        <Dialog
          open={this.state.showApplyForm}
          onClose={this.handleApplyFormClose}
          fullWidth
        >
          <DialogTitle>
            <IconButton
              aria-label="close"
              className={classes.closeButton}
              onClick={this.handleApplyFormClose}
            >
              <Close />
            </IconButton>
          </DialogTitle>
          <DialogContent>
            <Typography
              variant="subtitle1"
              color="primary"
              align="center"
              gutterBottom
            >
              {`Fill all required details and apply`}
            </Typography>
            <form onSubmit={this.onSubmitHandler}>
              <Grid container spacing={2} className={classes.formContainer}>
                <Grid container spacing={2}>
                  {this.state.error && (
                    <Grid item xs={12}>
                      <Alert severity="error">{`${this.state.errorMessage}`}</Alert>
                    </Grid>
                  )}
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      multiline
                      rows={2}
                      rowsMax={3}
                      name="message"
                      value={this.state.message}
                      onChange={this.onChangeHandler}
                      label="Message"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="myExperience"
                      value={this.state.myExperience}
                      onChange={this.onChangeHandler}
                      label="Year/s of experience"
                    />
                  </Grid>

                  {this.state.loading && (
                    <Grid item xs={12}>
                      <LinearProgress />
                    </Grid>
                  )}
                  <Grid item xs={12}>
                    <Box mt={2}>
                      <Button
                        fullWidth
                        type="submit"
                        variant="contained"
                        color="primary"
                        disabled={this.state.error || this.state.loading}
                      >
                        Submit Application
                      </Button>
                    </Box>
                  </Grid>
                </Grid>
              </Grid>
            </form>
          </DialogContent>
        </Dialog>
        <ScrollTop {...this.props} className={classes.backToTop}>
          <Fab color="secondary" aria-label="scroll back to top">
            <KeyboardArrowUpIcon />
          </Fab>
        </ScrollTop>
        {/* <Footer /> */}
      </>
    );
  }
}
export default withStyles(useStyles)(FullJdDetails);
