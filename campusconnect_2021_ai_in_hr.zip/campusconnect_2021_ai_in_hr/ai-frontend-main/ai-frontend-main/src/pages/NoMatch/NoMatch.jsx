import React, { Component } from "react";
import { Typography } from "@material-ui/core";
import { Link } from "react-router-dom";

export default class NoMatch extends Component {
  render() {
    return (
      <div className="no-match">
        <Typography component="h4" variant="h4">
          404 error
        </Typography>
        <Link to="/">
          <Typography component="h6" variant="h6">
            Go Home
          </Typography>
        </Link>
      </div>
    );
  }
}
