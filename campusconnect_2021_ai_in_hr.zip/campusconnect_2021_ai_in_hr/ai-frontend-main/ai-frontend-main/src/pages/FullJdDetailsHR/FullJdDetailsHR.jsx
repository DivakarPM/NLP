import React, { Component } from "react";
import { Box, Container, Typography } from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";
import PropTypes from "prop-types";
import useScrollTrigger from "@material-ui/core/useScrollTrigger";
import Fab from "@material-ui/core/Fab";
import KeyboardArrowUpIcon from "@material-ui/icons/KeyboardArrowUp";
import Zoom from "@material-ui/core/Zoom";
import Header from "../../components/Common/Header/Header";
import { Helmet } from "react-helmet";
import axios from "axios";
import { getJdByIdAPI } from "../../utils/endPoints";
import { Paper } from "@material-ui/core";
import * as dayjs from "dayjs";
import JdTable from "../../components/Hr/JdTable/JdTable";

const useStyles = (theme) => ({
  root: {
    marginTop: theme.spacing(16),
  },
  heroContent: {
    padding: theme.spacing(0, 6, 2),
  },
  textBlue: {
    color: "#3495DB",
  },
  backToTop: {
    position: "fixed",
    bottom: theme.spacing(2),
    right: theme.spacing(2),
  },
  descriptionPaper: {
    padding: theme.spacing(6, 10, 6),
  },
  sizeAvatar: {
    height: theme.spacing(6),
    width: theme.spacing(6),
  },
});

function ScrollTop(props) {
  const { children, window, classes } = props;
  const trigger = useScrollTrigger({
    target: window ? window() : undefined,
    disableHysteresis: true,
    threshold: 100,
  });

  const handleClick = (event) => {
    const anchor = (event.target.ownerDocument || document).querySelector(
      "#back-to-top-anchor"
    );

    if (anchor) {
      anchor.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  };

  return (
    <Zoom in={trigger}>
      <div
        onClick={handleClick}
        role="presentation"
        className={classes.backToTop}
      >
        {children}
      </div>
    </Zoom>
  );
}
ScrollTop.propTypes = {
  children: PropTypes.element.isRequired,
  window: PropTypes.func,
};
class FullJdDetailsHR extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      title: "",
      description: "",
      role: "",
      link: "",
      experience: "",
      openings: "",
      lastDate: "",
      location: "",
      active: "",
      postedAt: "",
      postedBy: "",
      applications: [],
    };
  }

  componentDidMount() {
    this.getJob();
  }

  getJob = () => {
    this.setState({ isLoading: true });
    axios
      .get(getJdByIdAPI + this.props.match.params.id)
      .then((response) => {
        this.setState({
          title: response.data.title,
          description: response.data.description,
          role: response.data.role,
          link: response.data.link,
          experience: response.data.experience,
          openings: response.data.openings,
          lastDate: response.data.last_date,
          active: response.data.active,
          location: response.data.location,
          postedAt: response.data.posted_at,
          postedBy: response.data.posted_by.name,
          isLoading: false,
        });
        this.getResults();
      })
      .catch((err) => {
        console.warn(err);
      });
  };

  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }

  render() {
    const { classes } = this.props;
    const {
      title,
      description,
      role,
      active,
      experience,
      openings,
      postedAt,
      postedBy,
      location,
    } = this.state;
    return (
      <>
        <Helmet>
          <title>Job Details | AI in HR</title>
        </Helmet>
        <Header />
        <div id="back-to-top-anchor" />
        {!this.state.isLoading && (
          <Container className={classes.root}>
            <Box className={classes.heroContent}>
              <Container>
                <Paper className={classes.descriptionPaper}>
                  <Box>
                    <Typography gutterBottom variant="h4">
                      {active ? `${title}` : `[INACTIVE] ${title}`}
                    </Typography>
                    <Typography
                      variant="body1"
                      color="textSecondary"
                      component="p"
                    >
                      Posted At:{" "}
                      {dayjs(postedAt + "Z").format("ddd, MM : h:mm a")} by{" "}
                      {postedBy}
                    </Typography>

                    <Typography variant="h6" gutterBottom>
                      <Box fontWeight="600">Role</Box>
                      <Box fontWeight="400">{role}</Box>
                    </Typography>
                    <Typography variant="h6" color="textPrimary" gutterBottom>
                      <Box fontWeight="600">Location</Box>
                      <Box fontWeight="400">{location}</Box>
                    </Typography>
                    <Typography variant="h6" color="textPrimary" gutterBottom>
                      <Box fontWeight="600">Minimum Experience</Box>
                      <Box fontWeight="400">{experience} year/s</Box>
                    </Typography>
                    <Typography variant="h6" color="textPrimary" gutterBottom>
                      <Box fontWeight="600">Openings</Box>
                      <Box fontWeight="400">{openings}</Box>
                    </Typography>
                    <Typography variant="h6" color="textPrimary" gutterBottom>
                      <Box fontWeight="600">Job Description</Box>
                    </Typography>
                    {description.split("\n").map((line) => (
                      <Typography
                        variant="body1"
                        color="textPrimary"
                        gutterBottom
                      >
                        <Box fontWeight="400">{line}</Box>
                      </Typography>
                    ))}
                  </Box>
                  <Box mt={4}>
                    <Typography gutterBottom variant="h6">
                      <Box fontWeight="600">Job Applications</Box>
                    </Typography>
                  </Box>
                  <JdTable jdId={this.props.match.params.id} />
                </Paper>
              </Container>
            </Box>
          </Container>
        )}
        <ScrollTop {...this.props} className={classes.backToTop}>
          <Fab color="secondary" aria-label="scroll back to top">
            <KeyboardArrowUpIcon />
          </Fab>
        </ScrollTop>
        {/* <Footer /> */}
      </>
    );
  }
}
export default withStyles(useStyles)(FullJdDetailsHR);
