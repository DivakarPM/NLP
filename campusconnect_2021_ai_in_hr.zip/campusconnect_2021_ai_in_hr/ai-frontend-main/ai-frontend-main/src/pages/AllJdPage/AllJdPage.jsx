import React, { Component } from "react";
import { Box, Button, Container, Grid, Typography } from "@material-ui/core";
import { Card } from "@material-ui/core";
import { CardActions } from "@material-ui/core";
import { CardContent } from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";
import PropTypes from "prop-types";
import useScrollTrigger from "@material-ui/core/useScrollTrigger";
import Fab from "@material-ui/core/Fab";
import KeyboardArrowUpIcon from "@material-ui/icons/KeyboardArrowUp";
import Zoom from "@material-ui/core/Zoom";
import Header from "../../components/Common/Header/Header";
import { Helmet } from "react-helmet";
import axios from "axios";
import { CardHeader } from "@material-ui/core";
import { getAllJdAPI } from "../../utils/endPoints";
import { Link } from "react-router-dom";
import * as dayjs from "dayjs";

// import Footer from "../../components/Commom/Footer/Footer";

const useStyles = (theme) => ({
  root: {
    marginBottom: theme.spacing(20),
  },
  heroContent: {
    padding: theme.spacing(0, 2, 2),
  },
  heroButtons: {
    marginTop: theme.spacing(4),
  },
  textBlue: {
    color: "#3495DB",
  },
  backToTop: {
    position: "fixed",
    bottom: theme.spacing(2),
    right: theme.spacing(2),
  },
  jobsContainer: {
    padding: theme.spacing(0, 12, 0),
  },
});

function ScrollTop(props) {
  const { children, window, classes } = props;
  const trigger = useScrollTrigger({
    target: window ? window() : undefined,
    disableHysteresis: true,
    threshold: 100,
  });

  const handleClick = (event) => {
    const anchor = (event.target.ownerDocument || document).querySelector(
      "#back-to-top-anchor"
    );

    if (anchor) {
      anchor.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  };

  return (
    <Zoom in={trigger}>
      <div
        onClick={handleClick}
        role="presentation"
        className={classes.backToTop}
      >
        {children}
      </div>
    </Zoom>
  );
}
ScrollTop.propTypes = {
  children: PropTypes.element.isRequired,
  window: PropTypes.func,
};
class AllJdPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      jobs: [],
    };
  }

  componentDidMount() {
    this.getAllJobs();
  }

  getAllJobs() {
    this.setState({ isLoading: true });
    axios
      .get(getAllJdAPI)
      .then((response) => {
        this.setState({ jobs: response.data, isLoading: false });
      })
      .catch((err) => {
        console.warn(err);
      });
  }
  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }

  render() {
    const { classes } = this.props;
    return (
      <>
        <Helmet>
          <title>Jobs | AI in HR</title>
        </Helmet>
        <Header />
        <div id="back-to-top-anchor" />
        <Container className={classes.root}>
          <Box className={classes.heroContent}>
            <Container>
              <Box mt={12} mb={4}>
                <Typography
                  component="h4"
                  variant="h4"
                  align="center"
                  className={classes.textBlue}
                  gutterBottom
                >
                  Apply for your next job!
                </Typography>
              </Box>
              <Container className={classes.jobsContainer}>
                <Grid container spacing={3}>
                  {this.state.jobs.map((jd) => (
                    <Grid key={jd.id} item xs={12}>
                      <Card>
                        <CardHeader title={jd.title} />
                        <CardContent>
                          <Box mt={-2}>
                            <Typography variant="subtitle1" gutterBottom>
                              {jd.role}
                            </Typography>
                            <Typography
                              variant="subtitle1"
                              color="textSecondary"
                              component="p"
                            >
                              Minimum Experience: {jd.experience}
                            </Typography>
                            <Typography
                              variant="subtitle1"
                              color="textSecondary"
                              component="p"
                            >
                              Job Location: {jd.location}
                            </Typography>
                            <Typography
                              variant="subtitle1"
                              color="textSecondary"
                              component="p"
                            >
                              Last Date to Apply :{" "}
                              {dayjs(jd.last_date).format("DD/MM/YYYY")}
                            </Typography>
                          </Box>
                        </CardContent>
                        <CardActions>
                          <Link
                            to={`/job-description/${jd.id}`}
                            target="_blank"
                          >
                            <Button size="small" color="secondary">
                              More Details
                            </Button>
                          </Link>
                        </CardActions>
                      </Card>
                    </Grid>
                  ))}
                </Grid>
              </Container>
            </Container>
          </Box>
        </Container>
        <ScrollTop {...this.props} className={classes.backToTop}>
          <Fab color="secondary" aria-label="scroll back to top">
            <KeyboardArrowUpIcon />
          </Fab>
        </ScrollTop>
        {/* <Footer /> */}
      </>
    );
  }
}
export default withStyles(useStyles)(AllJdPage);
