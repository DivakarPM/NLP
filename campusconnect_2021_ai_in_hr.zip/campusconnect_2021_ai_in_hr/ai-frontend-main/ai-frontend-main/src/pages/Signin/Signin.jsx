import React from "react";
import {
  Container,
  CssBaseline,
  Button,
  Typography,
  Box,
  TextField,
  Paper,
  MenuItem,
  CircularProgress,
  Avatar,
} from "@material-ui/core";
import { Link, Redirect } from "react-router-dom";
import Copyright from "../../components/Common/Copyright/Copyright";
import { Alert } from "@material-ui/lab";
import {
  signinUser,
  signinHr,
  removeError,
} from "../../redux/auth/auth.actions";
import { store } from "../../redux/store";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import { Component } from "react";
import { Helmet } from "react-helmet";
import { LockOutlined } from "@material-ui/icons";

const useStyles = (theme) => ({
  paper: {
    marginTop: theme.spacing(18),
    padding: theme.spacing(5, 8),
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 10,
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.primary.main,
  },
  form: {
    width: "100%",
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0),
    height: 45,
  },
  button: {
    height: 45,
  },
});

class Signin extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectUser: 0,
      email: "",
      password: "123456",
    };
  }
  static propTypes = {
    isAuth: PropTypes.bool,
    error: PropTypes.string,
    errorStatus: PropTypes.bool,
    isLoading: PropTypes.bool,
  };
  componentDidMount() {
    // to remove redux auth errors
    store.dispatch(removeError());
  }
  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }

  onChangeHandler = (e) => {
    store.dispatch(removeError());
    if (e.target.value !== " ") {
      this.setState({
        [e.target.name]: e.target.value,
      });
    }
  };

  handleChange = (event) => {
    store.dispatch(removeError());
    this.setState({
      selectUser: event.target.value,
    });
  };

  onSubmitHandler = (e) => {
    e.preventDefault();

    store.dispatch(removeError());
    if (this.state.selectUser === 1) {
      store.dispatch(signinUser(this.state.email, this.state.password));
    } else {
      store.dispatch(signinHr(this.state.email, this.state.password));
    }
  };

  render() {
    const { classes } = this.props;
    if (this.props.isAuth) {
      return <Redirect to="/dashboard" />;
    }
    return (
      <>
        <Helmet>
          <title>Signin | AI in HR</title>
        </Helmet>
        <Container component="main" maxWidth="sm">
          <CssBaseline />
          <Paper className={classes.paper} elevation={3}>
            <Avatar className={classes.avatar}>
              <LockOutlined />
            </Avatar>

            <form
              className={classes.form}
              noValidate
              onSubmit={this.onSubmitHandler}
            >
              {this.props.errorStatus && (
                <Alert severity="error">{this.props.error}</Alert>
              )}
              <TextField
                id="select-users"
                select
                required
                fullWidth
                margin="normal"
                label="Type"
                value={this.state.selectUser}
                onChange={this.handleChange}
                variant="outlined"
              >
                <MenuItem value={0}>{`I'm HR`}</MenuItem>
                <MenuItem value={1}>{`I'm User`}</MenuItem>
              </TextField>
              <TextField
                variant="outlined"
                margin="normal"
                required
                fullWidth
                label="Email Address"
                name="email"
                value={this.state.email}
                onChange={this.onChangeHandler}
                autoComplete="off"
              />
              <TextField
                variant="outlined"
                margin="normal"
                required
                fullWidth
                name="password"
                value={this.state.password}
                onChange={this.onChangeHandler}
                label="Password"
                type="password"
                autoComplete="off"
              />

              <Button
                color="secondary"
                variant="contained"
                type="submit"
                fullWidth
                disabled={this.props.isLoading || this.props.errorStatus}
                className={classes.submit}
              >
                <Box m={2} align="center">
                  {this.props.isLoading ? (
                    <CircularProgress color="primary" />
                  ) : (
                    `Sign In`
                  )}
                </Box>
              </Button>

              <Box align="center">
                <Link to="/signup">
                  <Typography variant="button" color="textPrimary">
                    {`Don't have an account? `}
                    <Typography variant="button" color="secondary">
                      {`Sign Up`}
                    </Typography>
                  </Typography>
                </Link>
              </Box>
            </form>
          </Paper>
          <Box mt={8}>
            <Copyright />
          </Box>
        </Container>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  isAuth: state.auth.isAuth,
  error: state.auth.error,
  errorStatus: state.auth.errorStatus,
  isLoading: state.auth.isLoading,
});

export default connect(mapStateToProps)(withStyles(useStyles)(Signin));
