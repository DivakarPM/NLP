import React, { Component } from "react";
import { Box, Button, Container, Grid, Typography } from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";
import PropTypes from "prop-types";
import useScrollTrigger from "@material-ui/core/useScrollTrigger";
import Fab from "@material-ui/core/Fab";
import KeyboardArrowUpIcon from "@material-ui/icons/KeyboardArrowUp";
import Zoom from "@material-ui/core/Zoom";
import Header from "../../components/Common/Header/Header";
import { Helmet } from "react-helmet";
import OrganiseResume from "../../assets/organise-resume.svg";
import Copyright from "../../components/Common/Copyright/Copyright";
import { Link } from "react-router-dom";

// import Footer from "../../components/Commom/Footer/Footer";

const useStyles = (theme) => ({
  "@global": {
    ul: {
      margin: 0,
      padding: 0,
      listStyle: "none",
    },
  },
  root: {
    marginBottom: theme.spacing(20),
  },
  heroContent: {
    padding: theme.spacing(20, 2, 2),
  },
  heroButtons: {
    marginTop: theme.spacing(4),
  },
  textBlue: {
    color: "#3495DB",
  },
  imageCenter: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  bodyImage: {
    padding: theme.spacing(0, 0, 5),
    height: "auto",
    width: "95%",
    [theme.breakpoints.down("sm")]: {
      height: "auto",
      width: "80%",
    },
  },
  backToTop: {
    position: "fixed",
    bottom: theme.spacing(2),
    right: theme.spacing(2),
  },
});

function ScrollTop(props) {
  const { children, window, classes } = props;
  const trigger = useScrollTrigger({
    target: window ? window() : undefined,
    disableHysteresis: true,
    threshold: 100,
  });

  const handleClick = (event) => {
    const anchor = (event.target.ownerDocument || document).querySelector(
      "#back-to-top-anchor"
    );

    if (anchor) {
      anchor.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  };

  return (
    <Zoom in={trigger}>
      <div
        onClick={handleClick}
        role="presentation"
        className={classes.backToTop}
      >
        {children}
      </div>
    </Zoom>
  );
}
ScrollTop.propTypes = {
  children: PropTypes.element.isRequired,
  window: PropTypes.func,
};
class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  componentDidMount() {}

  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }

  render() {
    const { classes } = this.props;
    return (
      <>
        <Helmet>
          <title>Home | AI in HR</title>
        </Helmet>
        <Header />
        <div id="back-to-top-anchor" />
        <Container className={classes.root}>
          <Box className={classes.heroContent}>
            <Container>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <Box mt={15}>
                    <Typography
                      component="h3"
                      variant="h3"
                      align="center"
                      className={classes.textBlue}
                      gutterBottom
                    >
                      Welcome to AI in HR
                    </Typography>
                    <Typography
                      variant="h5"
                      align="center"
                      color="textSecondary"
                      paragraph
                    >
                      AI Powered Talent acquisition tool
                    </Typography>
                    <div className={classes.heroButtons}>
                      <Grid container spacing={2} justify="center">
                        <Grid item>
                          <Link to="/signin">
                            <Button variant="contained" color="secondary">
                              Get Started
                            </Button>
                          </Link>
                        </Grid>
                        <Grid item>
                          <Link to="/about">
                            <Button variant="outlined" color="secondary">
                              Know More
                            </Button>
                          </Link>
                        </Grid>
                      </Grid>
                    </div>
                    <Copyright />
                  </Box>
                </Grid>
                <Grid item xs={12} sm={6} className={classes.imageCenter}>
                  <img
                    src={OrganiseResume}
                    alt="ai-in-hr"
                    className={classes.bodyImage}
                  />
                </Grid>
              </Grid>
            </Container>
          </Box>
        </Container>
        <ScrollTop {...this.props} className={classes.backToTop}>
          <Fab color="secondary" aria-label="scroll back to top">
            <KeyboardArrowUpIcon />
          </Fab>
        </ScrollTop>
        {/* <Footer /> */}
      </>
    );
  }
}
export default withStyles(useStyles)(Home);
