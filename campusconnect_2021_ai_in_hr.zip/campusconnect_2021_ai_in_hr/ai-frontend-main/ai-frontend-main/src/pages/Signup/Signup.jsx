import React from "react";
import {
  Container,
  CssBaseline,
  Button,
  Typography,
  Box,
  TextField,
  Paper,
  MenuItem,
  CircularProgress,
  Avatar,
} from "@material-ui/core";
import { Link, Redirect } from "react-router-dom";
import Copyright from "../../components/Common/Copyright/Copyright";
import { Alert } from "@material-ui/lab";
import MuiPhoneNumber from "material-ui-phone-number";
import {
  signupUser,
  signupHr,
  removeError,
} from "../../redux/auth/auth.actions";
import { store } from "../../redux/store";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import { Component } from "react";
import { Helmet } from "react-helmet";
import { PersonOutline } from "@material-ui/icons";

const useStyles = (theme) => ({
  paper: {
    marginTop: theme.spacing(3),
    padding: theme.spacing(5, 8),
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 10,
  },
  form: {
    width: "100%",
    marginTop: theme.spacing(1),
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.primary.main,
  },
  submit: {
    margin: theme.spacing(3, 0),
    height: 45,
  },
  button: {
    height: 45,
  },
});

class Signup extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectUser: 0,
      name: "",
      email: "",
      password: "123456",
      contact_number: "",
      address: "",
    };
  }
  static propTypes = {
    isAuth: PropTypes.bool,
    error: PropTypes.string,
    errorStatus: PropTypes.bool,
    isLoading: PropTypes.bool,
  };
  componentDidMount() {
    // to remove redux auth errors
    store.dispatch(removeError());
  }
  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }

  onChangeHandler = (e) => {
    store.dispatch(removeError());
    if (e.target.value !== " ") {
      this.setState({
        [e.target.name]: e.target.value,
      });
    }
  };

  handleChange = (event) => {
    store.dispatch(removeError());
    this.setState({
      selectUser: event.target.value,
    });
  };
  mobilechangeHandler = (value) => {
    store.dispatch(removeError());
    this.setState({
      contact_number: value,
    });
  };
  onSubmitHandler = (e) => {
    e.preventDefault();
    store.dispatch(removeError());
    if (this.state.selectUser === 1) {
      store.dispatch(
        signupUser(
          this.state.name,
          this.state.email,
          this.state.password,
          this.state.contact_number,
          this.state.address
        )
      );
    } else {
      store.dispatch(
        signupHr(
          this.state.name,
          this.state.email,
          this.state.password,
          this.state.contact_number,
          this.state.address
        )
      );
    }
  };

  render() {
    const { classes } = this.props;
    if (this.props.isAuth) {
      return <Redirect to="/dashboard" />;
    }
    return (
      <>
        <Helmet>
          <title>Signin | AI in HR</title>
        </Helmet>
        <Container component="main" maxWidth="sm">
          <CssBaseline />
          <Paper className={classes.paper} elevation={3}>
            <Avatar className={classes.avatar}>
              <PersonOutline />
            </Avatar>

            <form
              className={classes.form}
              noValidate
              onSubmit={this.onSubmitHandler}
            >
              {this.props.errorStatus && (
                <Alert severity="error">{this.props.error}</Alert>
              )}
              <TextField
                id="select-users"
                select
                required
                fullWidth
                margin="normal"
                label="Type"
                value={this.state.selectUser}
                onChange={this.handleChange}
                variant="outlined"
              >
                <MenuItem value={0}>{`I'm HR`}</MenuItem>
                <MenuItem value={1}>{`I'm User`}</MenuItem>
              </TextField>
              <TextField
                variant="outlined"
                margin="normal"
                required
                fullWidth
                label="Full Name"
                name="name"
                value={this.state.name}
                onChange={this.onChangeHandler}
                autoComplete="off"
              />
              <TextField
                variant="outlined"
                margin="normal"
                required
                fullWidth
                label="Email Address"
                name="email"
                value={this.state.email}
                onChange={this.onChangeHandler}
                autoComplete="off"
              />
              <TextField
                variant="outlined"
                margin="normal"
                required
                fullWidth
                name="password"
                value={this.state.password}
                onChange={this.onChangeHandler}
                label="Password"
                type="password"
                autoComplete="off"
              />
              <MuiPhoneNumber
                margin="normal"
                required
                variant="outlined"
                fullWidth
                id="contact"
                label="Contact"
                name="contact"
                defaultCountry={"in"}
                autoComplete="off"
                onChange={this.mobilechangeHandler}
              />
              <TextField
                variant="outlined"
                margin="normal"
                required
                fullWidth
                label="Address"
                name="address"
                value={this.state.address}
                onChange={this.onChangeHandler}
                autoComplete="off"
              />
              <Button
                color="secondary"
                variant="contained"
                type="submit"
                fullWidth
                disabled={this.props.isLoading || this.props.errorStatus}
                className={classes.submit}
              >
                <Box m={2} align="center">
                  {this.props.isLoading ? (
                    <CircularProgress color="primary" />
                  ) : (
                    `Sign Up`
                  )}
                </Box>
              </Button>
              <Box align="center">
                <Link to="/signin">
                  <Typography variant="button" color="textPrimary">
                    {`Already have an account? `}
                    <Typography variant="button" color="secondary">
                      {`Sign In`}
                    </Typography>
                  </Typography>
                </Link>
              </Box>
            </form>
          </Paper>
          <Box mt={8}>
            <Copyright />
          </Box>
        </Container>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  isAuth: state.auth.isAuth,
  error: state.auth.error,
  errorStatus: state.auth.errorStatus,
  isLoading: state.auth.isLoading,
});

export default connect(mapStateToProps)(withStyles(useStyles)(Signup));
