import {
  LOGIN_HR_SUCCESS,
  LOGIN_USER_SUCCESS,
  LOGOUT_SUCCESS,
  AUTH_ERROR,
  REMOVE_ERROR,
  IS_LOADING,
} from "./auth.types";

const initialState = {
  isAuth: false,
  type: null,
  userData: null,
  hrData: null,
  errorStatus: false,
  error: null,
  isLoading: false,
};

export default function foo(state = initialState, action) {
  switch (action.type) {
    case IS_LOADING:
      return {
        ...state,
        isLoading: true,
      };
    case REMOVE_ERROR:
      return {
        ...state,
        isAuth: false,
        type: null,
        userData: null,
        hrData: null,
        error: null,
        errorStatus: false,
        isLoading: false,
      };
    case LOGIN_USER_SUCCESS:
      return {
        ...state,
        isAuth: true,
        type: "user",
        userData: action.payload,
        hrData: null,
        error: null,
        errorStatus: false,
        isLoading: false,
      };
    case LOGIN_HR_SUCCESS:
      return {
        ...state,
        isAuth: true,
        type: "hr",
        userData: null,
        hrData: action.payload,
        error: null,
        errorStatus: false,
        isLoading: false,
      };
    case AUTH_ERROR:
      return {
        ...state,
        isAuth: false,
        type: null,
        userData: null,
        hrData: null,
        error: action.payload.error,
        errorStatus: true,
        isLoading: false,
      };
    case LOGOUT_SUCCESS:
      return {
        ...state,
        isAuth: false,
        type: null,
        userData: null,
        hrData: null,
        error: null,
        errorStatus: false,
        isLoading: false,
      };

    default:
      return state;
  }
}
