import axios from "axios";
import {
  LOGIN_HR_SUCCESS,
  LOGIN_USER_SUCCESS,
  LOGOUT_SUCCESS,
  AUTH_ERROR,
  REMOVE_ERROR,
  IS_LOADING,
} from "./auth.types";
import {
  signinUserAPI,
  signinHrAPI,
  signupUserAPI,
  signupHrAPI,
} from "../../utils/endPoints";

// Signin User
export const signinUser = (email, password) => (dispatch) => {
  //headers
  isLoading();
  const config = {
    headers: {
      "content-type": "application/json",
    },
  };
  // Body
  const body = JSON.stringify({
    email,
    password,
  });

  axios
    .post(signinUserAPI, body, config)
    .then((response) => {
      if (response.status === 200) {
        dispatch({
          type: LOGIN_USER_SUCCESS,
          payload: response.data,
        });
      }
    })
    .catch((err) => {
      if (err.response.status === 403) {
        dispatch({
          type: AUTH_ERROR,
          payload: err.response.data,
        });
      }
    });
};

// Signin HR
export const signinHr = (email, password) => (dispatch) => {
  //headers
  const config = {
    headers: {
      "content-type": "application/json",
    },
  };
  // Body
  const body = JSON.stringify({
    email: email,
    password: password,
  });

  axios
    .post(signinHrAPI, body, config)
    .then((response) => {
      if (response.status === 200) {
        dispatch({
          type: LOGIN_HR_SUCCESS,
          payload: response.data,
        });
      }
    })
    .catch((err) => {
      if (err.response.status === 403) {
        dispatch({
          type: AUTH_ERROR,
          payload: err.response.data,
        });
      }
    });
};

// Signup User
export const signupUser = (name, email, password, contact_number, address) => (
  dispatch
) => {
  //headers
  const config = {
    headers: {
      "content-type": "application/json",
    },
  };
  // Body
  const body = JSON.stringify({
    name,
    email,
    password,
    contact_number,
    address,
  });

  axios
    .post(signupUserAPI, body, config)
    .then((response) => {
      if (response.status === 201) {
        dispatch({
          type: LOGIN_USER_SUCCESS,
          payload: response.data,
        });
      }
    })
    .catch((err) => {
      if (err.response.status === 403) {
        dispatch({
          type: AUTH_ERROR,
          payload: err.response.data,
        });
      }
    });
};

// Signup HR
export const signupHr = (name, email, password, contact_number, address) => (
  dispatch
) => {
  //headers
  const config = {
    headers: {
      "content-type": "application/json",
    },
  };
  // Body
  const body = JSON.stringify({
    name,
    email,
    password,
    contact_number,
    address,
  });

  axios
    .post(signupHrAPI, body, config)
    .then((response) => {
      if (response.status === 201) {
        dispatch({
          type: LOGIN_HR_SUCCESS,
          payload: response.data,
        });
      }
    })
    .catch((err) => {
      if (err.response.status === 403) {
        dispatch({
          type: AUTH_ERROR,
          payload: err.response.data,
        });
      }
    });
};

// LOGOUT
export const logout = () => (dispatch) => {
  dispatch({
    type: REMOVE_ERROR,
  });
  dispatch({
    type: LOGOUT_SUCCESS,
  });
};

// REMOVE ERROR
export const removeError = () => (dispatch) => {
  dispatch({
    type: REMOVE_ERROR,
  });
};

// LOADING
export const isLoading = () => (dispatch) => {
  dispatch({
    type: IS_LOADING,
  });
};
